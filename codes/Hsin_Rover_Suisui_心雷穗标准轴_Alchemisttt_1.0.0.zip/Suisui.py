# -*- coding: utf-8 -*-
r"""穗穗（3 号位，冷凝）—— v2 标准轴

本文件由 build_xrs_team_v2.py 生成（心雷穗 v2.0.0 标准轴）。
· 只改旋钮：每个角色的常量都放在它自己那一段的开头。
· 只改一拍：找 `_beat_<拍名>` 方法；拍序/预算/契约在文件顶部的 BEATS 表里。
· 公共引擎在文件末尾「共用骨架」一段；改它请改生成器的 shared_*.txt 再重新生成三份。
"""
import time

import cv2
import numpy as np

from src.Labels import Labels
from src.char.BaseChar import BaseChar, Elements, SwitchPriority

STATE_ATTR = '_v2_state'
ME = 'Suisui'

INITIAL_STATE = {'step': 'b1_suisui_open', 'phase': 'q', 'next': 'Suisui', 'idle': 0}

# ══════════════════════════════════════════════════════════════════════════
#  ★ BEATS 表派生数据（唯一来源 = build_xrs_team_v2.py 的 BEATS）—— 不要手改
# ══════════════════════════════════════════════════════════════════════════
BEAT_ORDER = (
    'b1_suisui_open',
    'b2_rover_drop',
    'b3_suisui_mux',
    'b4_rover_mux',
    'b5_suisui_burst',
    'b6_rover_intro',
    'b7_hsin_mux',
    'b8_rover_burst',
    'b9_hsin_main',
)

BEAT_WHO = {
    'b1_suisui_open': 'Suisui',
    'b2_rover_drop': 'Rover',
    'b3_suisui_mux': 'Suisui',
    'b4_rover_mux': 'Rover',
    'b5_suisui_burst': 'Suisui',
    'b6_rover_intro': 'Rover',
    'b7_hsin_mux': 'Hsin',
    'b8_rover_burst': 'Rover',
    'b9_hsin_main': 'Hsin',
}

BEAT_CAP = {
    'b1_suisui_open': 10.0,
    'b2_rover_drop': 4.5,
    'b3_suisui_mux': 5.0,
    'b4_rover_mux': 5.0,
    'b5_suisui_burst': 18.0,
    'b6_rover_intro': 18.0,
    'b7_hsin_mux': 5.0,
    'b8_rover_burst': 30.0,
    'b9_hsin_main': 45.0,
}

BEAT_NOTE = {
    'b1_suisui_open': {
        'q': 'a123 E a      攒水云息 → 强化E(醒春潮)升空 → 下落A',
        'l': '[变] a         变奏入场后只补一个 a（水云息已被变奏消耗，E 放不出来）',
        'pre': '开局首发；循环轴由心月狐满协奏变奏过来',
        'out': '穗穗水云息已消耗、已尝试过强化E',
        'fb': '等不到 E 就狂按后照常交棒（不空转）',
    },
    'b2_rover_drop': {
        'q': 'a a            下落A + 落地顿一下再补 A1',
        'l': 'a a            同上',
        'pre': '穗穗直切过来',
        'out': '雷主落地、电涌开始积累',
        'fb': '下落A 判定失败就只打地面A',
    },
    'b3_suisui_mux': {
        'q': 'a1 a2 →合轴切出  穗穗A2转身后退的后摇里切给雷主',
        'l': 'a1 a2 →合轴切出  同上',
        'pre': '雷主直切过来',
        'out': '穗穗后摇已被雷主的动作填掉（合轴）',
        'fb': '★保守出口：合轴窗口内没切过去 → 补一下普攻后走普通直切',
    },
    'b4_rover_mux': {
        'q': 'a1 a2 a3 →合轴切回  雷主往后撤的后摇里切回穗穗',
        'l': 'a1 a2 a3 →合轴切回  同上',
        'pre': '穗穗合轴切出',
        'out': '雷主后摇已被穗穗填掉（合轴）',
        'fb': '★保守出口：同上',
    },
    'b5_suisui_burst': {
        'q': 'a12 E Q R      第二格回路满 → 小技能充满回路 → 声骸 → 大招',
        'l': 'a12 E (a34) QR 同启动，括号是可选分支（本实现按保守分支跳过 a34）',
        'pre': '雷主合轴切回',
        'out': '穗穗芳菲信满 + 大招已放 + 满协奏（→ 变奏雷主）',
        'fb': '★作者的显式分支：第二格回路没满 → 不放小技能，一路 a 到回路满',
    },
    'b6_rover_intro': {
        'q': '[变] a E       变奏登场 → a一下 → 立刻小技能(强E·超负荷)',
        'l': '[变] a E       同上',
        'pre': '变奏（穗穗满协奏离场）',
        'out': '雷主超负荷已挂上（10 层电磁效应，供心月狐强化重击）',
        'fb': '寻电涌：打普攻到电涌满再按 E；上限内没满就照常按一次 E 走人',
    },
    'b7_hsin_mux': {
        'q': 'a1 a2 →合轴切回  心月狐尾巴甩到身后 → 切回雷主',
        'l': 'a1 a2 →合轴切回  同上',
        'pre': '雷主直切过来，心月狐带变奏',
        'out': '心月狐的前段后摇被雷主填掉（合轴）',
        'fb': '★保守出口：合轴窗口内没切过去 → 走普通直切',
    },
    'b8_rover_burst': {
        'q': 'a a E R a      打满电涌 → 强化E → 大招 → 补一个a垫下一轮',
        'l': 'a E R a        比启动少一个 a',
        'pre': '心月狐合轴切出',
        'out': '雷主满协奏 + 电涌回复（→ 变奏心月狐）',
        'fb': '上限内没攒满就少打，照常放 R',
    },
    'b9_hsin_main': {
        'q': '[变] a Z Q R e a12 E a1234 Z R',
        'l': '同上（跑完这一拍切到循环相位）',
        'pre': '变奏（雷主满协奏离场）',
        'out': '心月狐：应世相强化重击 → 变身 → 照世相万阙连衡 → 终结重击·临寰宇 → 二段大(R2)',
        'fb': '二段大没亮坚决不按 R（否则会切回原形态）；照世相模板读不到就用固定时长兜底',
    },
}


def team_state(task):
    """队伍共享状态（挂在 task 上，三名角色各持一份同名代码也能看到同一个进度）。"""
    st = getattr(task, STATE_ATTR, None)
    if not isinstance(st, dict):
        st = dict(INITIAL_STATE)
        setattr(task, STATE_ATTR, st)
    return st


def con_of(char):
    try:
        return float(char.get_current_con() or 0)
    except Exception:
        return 0.0

class Suisui(BaseChar):
    """穗穗（3 号位，冷凝）—— v2 标准轴负责拍：b1 / b3 / b5。

    契约卡（改这一拍前先读）：
      b1  前置=开局首发或心月狐满协奏变奏过来   产出=水云息已消耗
          兜底=等不到E就狂按后照常交棒
      b3  前置=雷主直切过来                    产出=后摇被雷主填掉（合轴）
          兜底=合轴窗口没切过去 → 补一下普攻走普通直切
      b5  前置=雷主合轴切回                    产出=芳菲信满+大招+满协奏
          兜底=第二格回路没满就不放小技能，一路a到回路满
    """

    MY_STEPS = ('b1_suisui_open', 'b3_suisui_mux', 'b5_suisui_burst')
    VISIT_CAPS = {'b1_suisui_open': 10.0, 'b3_suisui_mux': 5.0, 'b5_suisui_burst': 18.0}

    # ─────────────────── 旋钮（只改这里）───────────────────
    E_TAP = 0.05            # 按 E 的按住时长（长动画后建议 0.2~0.25）
    E_PRESS_INTERVAL = 0.25 # 狂按 E 的间隔
    E_WAIT_BEFORE_SPAM = 3.0# 「小等」多久没亮转狂按
    E_SPAM_TIME = 2.5       # 狂按 E 的窗口
    RISE_WAIT = 0.6         # E 之后等升空/起手的固定等待
    AIR_ATTACK_WAIT = 0.35  # 升空后再点下落A 的间隔
    WATER_BAR_CAP = 12      # b1 攒水云息最多打几下
    BURST_BAR_CAP = 6       # b5 攒第二格回路最多打几下
    BURST_FALLBACK_CAP = 10 # b5 兜底「一路a到回路满」最多打几下
    FORTE3_TIMEOUT = 8.0    # 打满芳菲信的上限
    LOOP_B5_A34 = False     # ★保守分支：循环轴 b5 的 (a34) 一律跳过
                            #   （作者原话：a3a4 与 ERE 两套动作耗时几乎一样 → 跳过不亏）

    _PIN_RING = Elements.ICE

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._pin_ring_index()

    def _pin_ring_index(self):
        """钉死协奏环颜色（冷凝）。必须四处都钉：框架 apply_team_char_classes 会 __dict__.update 冲掉。"""
        try:
            self.ring_index = self._PIN_RING
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self._pin_ring_index()

    # ─────────────────── 穗穗的判据 ───────────────────
    def _forte2_available(self):
        """★「第二格回路」是否满 —— 这才是流程图 b5 写的前置条件。

        2026-10-06 实机返工：原来用 `_e_ready_now()`（CD读数/图标高亮）判，实机上一路假阴
        （打 6 下就报"没达标"），导致 b5 的小技能根本没按 → 协奏只有 0.46。
        `Labels.suisui_forte2` 是专门给这一格画的模板，直接查它。
        """
        try:
            return bool(self.task.find_one(Labels.suisui_forte2, threshold=0.75))
        except Exception:
            return False

    def _forte3_available(self):
        """芳菲信（三格回路）是否满：内置与工坊都用 threshold=0.75 才认。"""
        try:
            return bool(self.task.find_one(Labels.suisui_forte3, threshold=0.75))
        except Exception:
            return False

    def _wait_forte3(self, timeout=None):
        """打普攻直到芳菲信满（这是大招的回路）。图认不到就打到上限兜底，不卡死。"""
        timeout = self.FORTE3_TIMEOUT if timeout is None else timeout
        start = time.time()
        while self._elapsed(start) < timeout:
            if self._forte3_available():
                self.logger.info(f'xrs 穗穗 芳菲信满 用时{self._elapsed(start):.1f}s')
                return True
            self._check_combat_tolerant('打满芳菲信')
            self.click()
            time.sleep(0.15)
        self.logger.warning(f'xrs 穗穗 打满{timeout:.0f}s 芳菲信还没满 → 照放大招')
        return False

    def _e_ready(self):
        """醒春潮（强化E）能不能放：水云息(E回路)满 或 suisui_e1 亮。
        注意**不是** suisui_forte3（那是芳菲信/大招的回路）。"""
        try:
            return bool(self.is_e_forte_full()) or bool(self.task.find_one(Labels.suisui_e1))
        except Exception:
            return False

    def _e_rise(self, min_attacks=0, quick=False):
        """醒春潮（强化E·升空）：先「小等」看 E 亮不亮，等不到就**直接狂按 E**（一边按一边点普攻）。

        为什么不干等：17:05 那把循环第1拍干等 6s 没等到，后面 3A 还被本段预算掐掉。
        quick=True：变奏入场那一拍【水云息】已被消耗，E 根本放不出来 → 只快速试两下就过。
        """
        if quick:
            self._press_e('E(醒春潮·变奏入场后大概率放不出)', hold=self.E_TAP)
            self.click()
            time.sleep(self.E_PRESS_INTERVAL)
            self._press_e('E(醒春潮) 第2次', hold=self.E_TAP)
            self.logger.info('xrs 穗穗 醒春潮 quick 模式 → 直接去补普攻')
            time.sleep(self.RISE_WAIT)
            return False
        start = time.time()
        if min_attacks:
            self._attacks(min_attacks, 'b1前置')
        ready = False
        while self._elapsed(start) < self.E_WAIT_BEFORE_SPAM:
            if self._e_ready():
                ready = True
                break
            self._check_combat_tolerant('等E亮')
            self.click()
            time.sleep(0.15)
        self.logger.info(f'xrs 穗穗 E{"亮(水云息满)" if ready else "没等到(小等结束→直接狂按)"} '
                         f'用时{self._elapsed(start):.1f}s')
        start = time.time()
        fired = False
        while self._elapsed(start) < self.E_SPAM_TIME:
            self.send_resonance_key()
            self.click()
            time.sleep(self.E_PRESS_INTERVAL)
            if ready and not self._e_ready():
                fired = True
                break
        self._perf('e_rise', fired=int(fired), t=f'{self._elapsed(start):.2f}')
        self.logger.info(f'xrs 穗穗 醒春潮{"已确认放出" if fired else "未确认(已狂按E)"} '
                         f'用时{self._elapsed(start):.1f}s')
        time.sleep(self.RISE_WAIT)

    def _ult(self):
        """R = 共鸣解放：边A边按 R —— 能量没满游戏会忽略这次按键，满了那一瞬间自己放出去。"""
        return self._ult_until_fired('穗穗大招')

    # ─────────────────── 拍方法 ───────────────────
    def _beat_b1_suisui_open(self):
        """拍1 启动 a123 E a ／ 循环 [变] a"""
        st = team_state(self.task)
        if self._phase(st) == 'loop':
            self.logger.info('xrs 穗穗 b1(循环) 变奏入场 → 只补一个 a')
            self._attacks(1, 'b1循环')
        else:
            self.logger.info('xrs 穗穗 b1(启动) 攒水云息 → 强化E升空 → 下落A')
            self._attack_until(self._e_ready, cap=self.WATER_BAR_CAP, tag='b1·攒水云息')
            self._e_rise()
            time.sleep(self.AIR_ATTACK_WAIT)
            self._attacks(1, 'b1下落A')
        self._advance(st)
        self._switch_out(skip_con=True)

    def _beat_b3_suisui_mux(self):
        """拍3 穗穗 a1 a2 → 合轴切出（后摇交给雷主）"""
        st = team_state(self.task)
        self._attacks(2, 'b3')
        self._advance(st)
        rover = self._char_by_name('Rover')
        if not self._mux_switch(rover, tag='b3'):
            # ★保守出口：合轴没成立 → 补一下普攻再走普通直切（作者：两套耗时几乎一样）
            self.logger.warning('xrs 穗穗 b3 合轴没成立 → 补一下普攻后走普通直切（保守分支）')
            self._attacks(1, 'b3兜底')
            self._switch_out(skip_con=True)

    def _beat_b5_suisui_burst(self):
        """拍5 穗穗 a12 E (a34) Q R"""
        st = team_state(self.task)
        loop = (self._phase(st) == 'loop')
        self._attacks(2, 'b5')
        if loop and self.LOOP_B5_A34:
            self._attacks(2, 'b5·a34')
        full = self._attack_until(self._forte2_available, cap=self.BURST_BAR_CAP,
                                  tag='b5·第二格回路')
        if full:
            self._press_e('b5 小技能充满回路', hold=self.E_TAP)
            time.sleep(self.E_SETTLE)
        else:
            # ★作者显式分支：第二格回路没满 → 不要再放小技能，一路 a 到底把回路打满
            self.logger.warning('xrs 穗穗 b5 第二格回路没满 → 按作者口径不放小技能，一路a到回路满')
            self._attack_until(self._forte3_available, cap=self.BURST_FALLBACK_CAP,
                               tag='b5·兜底打满')
        self._echo()
        # ★用户逐帧纠正（56s）：「穗穗没等到满三格能量就放大招了」→ 必须**等芳菲信满**再按 R。
        #   `_wait_forte3` 内部有 timeout(8s) 兜底：图认不到就照放，绝不卡死。
        self._wait_forte3()
        ult_fired = self._ult()
        if ult_fired:
            # ★用户口径（2026-10-06 15:26）：「穗穗二段 R 后可狂按切人至雷主」。
            #   大招演出期间队伍UI不在，`_fill_con`/`_wait_team_visible` 只会白等
            #   （实测 15:26:21.270 放大招 → 25.284 "等了 4.0s 队伍UI都没回来"）。
            #   改成 `mash=True`：不等 UI，直接狂按数字键直到 in_team() 认到雷主
            #   （§2.6.1：游戏不缓存按键 ⇒ 一直按，总有一次落在演出刚结束那一帧）。
            self.logger.info('xrs 穗穗 b5 大招已出手 → 不等队伍UI，直接狂按切人至雷主')
        else:
            self._fill_con()
        self._advance(st)
        self._switch_out(skip_con=False, mash=bool(ult_fired))   # ★变奏：穗穗要顶满协奏再离场


    # ══════════════════ 状态机入口 ══════════════════
    def do_perform(self):
        st = team_state(self.task)
        step = st.get('step')
        if step not in self.MY_STEPS:
            return self._skip(st)
        # 认领成功：重置看门狗 + 设定本拍预算
        st['idle'] = 0
        self._visit_t0 = time.time()
        self.VISIT_CAP = self.VISIT_CAPS.get(step, 12.0)
        self._pin_ring_index()
        self._mark_busy(1.5)
        t0 = time.time()
        note = BEAT_NOTE.get(step, {})
        self.logger.info(f'xrs {ME} ▶ {step}（{note.get("l") if self._phase(st) == "loop" else note.get("q")}）'
                         f' 预算{self.VISIT_CAP:.0f}s')
        try:
            getattr(self, '_beat_' + step)()
        except Exception as e:
            self.logger.warning(f'xrs {ME} {step} 执行异常：{e} → 直接交棒（不结束战斗）')
            try:
                self._advance(st)
                self._switch_out(skip_con=True)
            except Exception:
                pass
        self._perf('beat', step=step, phase=self._phase(st),
                   t=f'{time.time() - t0:.2f}', con=f'{con_of(self):.2f}')
        self.logger.info(f'xrs {ME} 本轮({step}) 用时 {time.time() - t0:.2f}s 协奏={con_of(self):.2f}')


# ═══════════════════════════════════════════════════════════════════════════
#  共用骨架（v1 已被真机验证的 595 行 + v2 新增块）
#  ⚠️ 这一段的同名常量会**覆盖**上面 body 里的定义
# ═══════════════════════════════════════════════════════════════════════════

    # ═══════════════════════════════════════════════════════════════════════
    #  以下为「心雷穗」三名角色共用的骨架（由 build_xrs_team.py 统一生成）
    #  设计对照：固定顺序接力 / 自己按数字键切人 / 状态机写在 task._xrs_state 上
    # ═══════════════════════════════════════════════════════════════════════

    # ─────────────────────── 可调参数（公共） ───────────────────────
    BETWEEN_ATTACK = 0.22       # 普攻间隔
    DODGE_SETTLE = 0.25         # 闪避之后的落地缓冲
    ECHO_SETTLE = 0.2           # 按 Q（声骸）之后等动作
    FILL_CON_TIMEOUT = 3.5      # 交棒前顶满协奏的时间上限（Rover 在自己类里覆盖成 2.0）
    E_SETTLE = 0.35             # 一次 E 之后等动作
    TEAM_WAIT_TIMEOUT = 4.0     # 交棒前等"队伍UI回来"的上限（大招演出期间它是 False）
    RETRY_TEAM_WAIT = 2.5       # ★重试时只等 2.5s：'队伍UI没回来'基本都是游戏在演出/加载，久等没意义
    SWITCH_TIMEOUT = 2.0        # 单程切人最长尝试时间
    SWITCH_KEY_INTERVAL = 0.12  # 连按数字键的间隔
    SWITCH_SETTLE = 0.55        # 切过去之后等站稳（0.50/0.52 会把下一棒起手吞掉）
    SETTLE_ATTACK_INTERVAL = 0.42
    HANDOFF_CON_WAIT = 0.8      # 交棒前轮询协奏是否满的上限（必须在按切人键之前读）
    HANDOFF_CON_POLL = 0.1
    POKE_INTERVAL = 0.12        # 连点地板：再密会被吞/变成下落攻击
    POKE_READ_EVERY = 3         # 每 3 下普攻才读一次屏（≈0.36s，节流）
    SKIP_CHECK_AFTER_ULT = 5.0  # 大招/变身/交棒之后多久内不做"战斗结束"判定
    CON_FULL_EPS = 0.90         # ok-ww 把满环钳成 0.99、读数有 ±5% 抖动 → ≥0.90 就算满
    ULT_CD_MIN = 15.0           # R 的 CD 读数 ≥15s ⇒ "R 真放出去了"（三人大招 CD 都是 20s 级）
    VISIT_CAP = 12.0            # 兜底预算（没在 VISIT_CAPS 里配的段）
    intro_pending = False       # 持久标记：reset_state() 会把 has_intro 清成 False
    intro_motion_freeze_duration = 0.9

    # ══════════════ 本段站场的硬时间预算（抗干扰 + 不挨打） ══════════════
    def _over_budget(self):
        """本段站场时间是否已超过预算（超了就放弃剩余动作直接交棒）。"""
        cap = getattr(self, 'VISIT_CAP', 12.0)
        t0 = getattr(self, '_visit_t0', None)
        if t0 is None or time.time() - t0 < cap:
            return False
        self.logger.warning(f'xrs {ME} 本段站场已达上限 {cap:.0f}s → 放弃剩余动作直接交棒（抗干扰）')
        self._visit_t0 = time.time()      # 重置，避免同一段反复刷同一行日志
        return True

    # ══════════════════════════ 动作原语 ══════════════════════════
    def _dodge(self):
        try:
            self.task.send_key(self.task.key_config.get('Dodge Key', 'lshift'))
            time.sleep(self.DODGE_SETTLE)
        except Exception as e:
            self.logger.debug(f'xrs 闪避异常 {e}')

    def _press_e(self, tag, hold=0.05):
        """按一下 E（共鸣技能），**不看 resonance_available()**。

        为什么去掉门槛：resonance_available() = has_cd() = OCR 读技能图标上的冷却数字，
        第一下 E 之后它必然是 False → 会把整段强E 判成"不可用"跳过（旧队实战日志原文：
        `xbs 心 强E 不可用(E在冷却)→跳过`）。识别类判据只配写日志，不配决定流程。
        hold>0.06s 时 send_key 会走 keyDown→sleep→keyUp，一次调用同时覆盖短按/长按两种机制。
        """
        key = 'e'
        try:
            key = self.get_resonance_key()
        except Exception:
            pass
        try:
            self.task.send_key(key, down_time=max(hold, 0.02))
            time.sleep(0.05)
        except Exception as e:
            self.logger.debug(f'xrs {ME} {tag} 按键异常 {e}')
        self.logger.info(f'xrs {ME} {tag} ← 按下 E(hold={hold:.2f}s) CD读数={self._cd_readout()}')

    def _cd_readout(self, box='resonance'):
        """读一次技能冷却读数（只写日志 / 当"刚按的技能真放出来了"的复核）。"""
        try:
            return round(float(self.task.get_cd(box)), 2)
        except Exception:
            return None

    def _echo(self, tag=''):
        """Q = 声骸技能。★2026-10-06 15:4x 返工：**狂按 + 下游确认**，不再单发。

        证据（录像 `实战视频/2026-10-06 15-46-43.mp4`，26~41s 逐 0.25s 连拍）：
          **Q 图标从头到尾没有出现过冷却数字** ⇒ 雷主的 Q 一次都没放出去（b6、b8 各按过一次）。

        根因：原来走 `click_echo(time_out=0)` —— 那是**单发快路径**（按一次、不确认、不重试）。
        依据三条，都指向"必须多发 + 看下游"：
          · 指南 §2.6.1：「游戏侧按键**不排队**，长动画期间的按键会被**丢弃**」⇒ 楽山原文「**单发必丢**」；
          · 指南 §2.6.2③：「**出手确认只看下游链条**」；
          · **框架自带的 `src/char/Rover.py::perform_electric_routine()`** 就是这么写的：
            `self.wait_down(click=False); self.click_echo(); self.click_liberation(click_f=False)`
            —— 用的是**默认的 `click_echo()`**（内部每 0.1s 重按一次，
            直到 `echo_available()` 转 False = 图标转暗 = 游戏真的收了这一下），
            而不是 `time_out=0` 那个单发快路径。**这就是"上一轮已经改好一半"的那一处。**
        """
        try:
            if not self.echo_available():
                self.logger.info(f'xrs {ME} {tag} 声骸不可用（图标在读冷却）→ 跳过 Q')
                return False
            ok = self.click_echo()          # ★默认 time_out=1：内部每 0.1s 重按，直到图标转暗
            self.logger.info(f'xrs {ME} {tag} 声骸 Q '
                             f'{"已确认放出（图标转暗）" if ok else "按了但没读到转暗（不重试）"}')
            time.sleep(self.ECHO_SETTLE)
            return bool(ok)
        except Exception as e:
            self.logger.warning(f'xrs {ME} {tag} 声骸异常 {e}')
            return False

    def _shot(self, name):
        """留一张实战截图（随 OK-WW-log.zip 的 screenshots/ 回来）。

        【电涌】【照世心】【霆心域】这类资源条没有模板图，只能留证人工看 —— 别拿
        不可靠的识别结果去卡流程。"""
        try:
            self.task.screenshot(name)
        except Exception as e:
            self.logger.debug(f'xrs 截图 {name} 失败 {e}')

    # ═══════ 学 爱达千 那条轴：\u300c边A边等条件成立\u300d（不是站着干等） ═══════
    # ═══════════ 判定层（学爱达千 Aemeath.py）═══════════
    # 为什么不再用 get_cd() 的 CD 读数当"技能真放出去了吗"的凭据：
    #   OCR 有 ~1s 渲染延迟（按完立刻读是旧值），演出/特效糊住时整段读不到 → 判定又晚又错。
    # 改成：① 自己记"什么时候按过/放出去了"（_record / _since）；
    #       ② 时间口径用框架的 time_elapsed_accounting_for_freeze（**自动扣掉演出冻结时间**）；
    #       ③ "大招出手"用**队伍UI消失**判定（爱达千注释原文：演出期间的按键会被带过边界，
    #          演出一结束就兑现）—— 所以要狂按，而不是"按一次然后等读数"。
    LIB_CD = 25.0                 # 大招 CD（本队三人都是 20~25s 级）
    R_MASH_INTERVAL = 0.06        # 狂按 R 的间隔（爱达千 R2_KEY_INTERVAL=0.05 / EF_SPAM_INTERVAL=0.08）
    R_MASH_WINDOW = 3.5           # 狂按 R 的窗口长度（到点没出手就照常往下走）
    SPIN_CLICK_INTERVAL = 0.12    # "连点窗口"里的点击间隔（爱达千同名常量同值）
    A_CHAIN_INTERVAL = 0.33       # ★连续普攻的点击间隔：**按游戏普攻动画的自然节奏**。
                                  #   原来 0.16s 太密（日志里"连打 46 下"其实大半被吞，
                                  #   连段起不来 → 照世心/能量都攒不满）。参考包爱达千的连点窗口
                                  #   也是 4~5 下用 1.45s ≈ 0.33s/下。
    E_READY_CD = 0.6              # E 的 CD 读数 ≤0.6s ⇒ "有 E 可放"
    E_SPAM_MAX = 8                # 拍8 里"有E就放E"最多放几次（防呆）

    def _marks(self):
        m = getattr(self, '_xrs_marks', None)
        if m is None:
            m = {}
            self._xrs_marks = m
        return m

    def _record(self, key):
        """记一笔"这个动作我做过/这个技能放出去了"（自记账，供后面推算可用性）。"""
        self._marks()[key] = time.time()
        return self._marks()[key]

    def _elapsed(self, t):
        """从 t 到现在，**扣除演出冻结时间**（框架 API；拿不到就退回原始差值）。"""
        try:
            return self.time_elapsed_accounting_for_freeze(t)
        except Exception:
            return time.time() - t

    def _since(self, key):
        t = self._marks().get(key)
        return None if t is None else self._elapsed(t)

    def _lib_by_record_ready(self):
        """按自记账推算"现在能不能放大招"（没放过 / CD 已过 → 能）。只写日志用。"""
        s = self._since('liber')
        return s is None or s >= self.LIB_CD

    def _spam_r_until_fired(self, tag, window=None, poke=False, poll=None):
        """★狂按 R 直到"真出手"（学爱达千 `spam_r_e_until_lib`）。

        判定 = **队伍UI消失**（= 大招演出开始 = 出手了）。演出期间的按键会被"带过边界"，
        演出一结束就兑现 —— 所以狂按才对，而不是"按一次再等 CD 读数"（读数慢 ~1s）。
        出手或到窗口上限都停，两种情况都写日志（绝不卡死）。"""
        window = self.R_MASH_WINDOW if window is None else window
        poll = self.R_MASH_INTERVAL if poll is None else poll
        start = time.time()
        n = 0
        fired = False
        while self._elapsed(start) < window:
            if self._over_budget():
                break
            # 战斗判定用**容忍版**：演出/大招期间 target 会瞬断，单次失败不该结束整场
            #   （真·不在战斗时连续 20 次 ≈1.5s 后照样收场，不会像 19:12 那把空跑 55s）
            self._check_combat_tolerant('狂按R')
            n += 1
            try:
                self.send_liberation_key()
            except Exception as e:
                self.logger.debug(f'xrs {ME} 狂按 R 异常 {e}')
            try:
                self.task.next_frame()          # 每发一次键取一帧（参考包同款做法）
            except Exception:
                pass
            try:
                if not self.task.in_team()[0]:  # 队伍UI消失 = 演出开始 = 出手
                    fired = True
                    break
            except Exception:
                pass
            if poke:
                self.click()
            time.sleep(poll)
        if fired:
            self._record('liber')
        self.logger.info(f'xrs {ME} {tag} 狂按 R ×{n}（{self._elapsed(start):.2f}s）→ '
                         f'{"已出手（队伍UI消失）" if fired else "窗口到上限还没出手"}')
        return fired

    COMBAT_MISS_LIMIT = 20    # ★连续这么多次战斗判定失败才真的收场（演出/大招期间 target 会瞬断）

    def _check_combat_tolerant(self, tag=''):
        """战斗判定的**容忍版**：单次失败不结束战斗，连续 COMBAT_MISS_LIMIT 次才抛。

        为什么必须有：`task.check_combat()` 一旦判失败就 `raise_not_in_combat` → **整场战斗结束**。
        我们新加的狂按循环每 0.06s 查一次（比框架自己的频率高得多），演出/大招/变身期间
        target 瞬间丢失就会被命中 → 用户看到的"刚变奏到心，没过一会战斗就结束了"就是这么来的。
        容忍版：短暂瞬断继续按，真·不在战斗（连续 20 次 ≈ 1.5s）才让框架收场。"""
        try:
            self.check_combat()
            self._combat_miss = 0
        except Exception as e:
            self._combat_miss = getattr(self, '_combat_miss', 0) + 1
            if self._combat_miss >= self.COMBAT_MISS_LIMIT:
                self.logger.warning(f'xrs {ME} 战斗判定连续失败 {self._combat_miss} 次 → 收场（{e}）')
                raise
            self.logger.debug(f'xrs {ME} 战斗判定失败第{self._combat_miss}次（容忍中）{e}')

    def _frame_once(self):
        """取**最新**帧。

        ★关键（19:16 实测）：框架的画面只在有人调用 `task.next_frame()` 时才更新 ——
        我们的长按/等待循环里没人调，`find_one` 就一直在读**同一张旧帧**：
        表现是"高亮永远不变"（长按撞到 5.5s 上限才松、"等3.2s 高亮没亮"其实是读旧帧）。
        参考包（爱达千）的每个轮询都带一句 `self.task.next_frame()`，必须补上。"""
        try:
            f = self.task.next_frame()
            if f is not None:
                return f
        except Exception:
            pass
        try:
            return self.task.frame
        except Exception:
            return None

    def _e_ready_now(self, tag=''):
        """"有 E 就放 E" 的判据：E 的 CD 读数已好，**或** E 图标正在发光（高亮=可用）。

        用户口径（19:4x）："3ae强e 那段，也要检测有 e 就放 e，不然浪费时间"。
        用两个信号取或：① CD 读数 ≤ E_READY_CD；② 框架的颜色判定 box_highlighted('resonance')
        （E 图标上的白色高亮 —— 这是"技能可用"最直接的画面信号，不受 OCR 延迟影响）。"""
        cd = self._cd_readout()
        if cd is not None and cd <= self.E_READY_CD:
            return True, f'CD读数={cd}'
        try:
            if self.task.box_highlighted('resonance'):
                return True, '图标高亮'
        except Exception:
            pass
        return False, ''

    def _attack_chain(self, n, tag=''):
        """★连续 n 下普攻：**一口气打完**（中间不插闪避、不插任何检查）。

        用户口径（19:31）："3A 被拆分了，非常不连贯，浪费时间" ——
        上一版每下点击之间还夹了战斗判定/取帧，连段被打散。这里只发点击。"""
        if not n:
            return
        self._check_combat_tolerant(tag or '连打')
        for _ in range(int(n)):
            self.click()
            time.sleep(self.A_CHAIN_INTERVAL)
        self.logger.debug(f'xrs 心 {tag} 连打 {int(n)} 下')

    def _combo_3a_dodge_2a(self, tag=''):
        """★教学原文：「a，a，a **与闪同时按**，之后再接两次 a」。

        3 下普攻，**第 3 下按完立刻闪避**（闪避取消 3A 的后摇 —— 这是省时间的关键），
        再补 2 下普攻。**不用固定窗口等**：等窗口＝把后摇完整吃下来，
        强化形态的倒计时里白白烧掉一秒多（用户："a3 后摇太浪费时间导致掉 buff"）。"""
        self._check_combat_tolerant('3A+闪')
        for i in range(3):
            self.click()
            if i == 2:
                self._dodge()                       # ★与第 3 下同时（中间不再 sleep）
            else:
                time.sleep(self.A_CHAIN_INTERVAL)   # ★按普攻动画的自然节奏（0.33s）
        for _ in range(2):
            self.click()
            time.sleep(self.A_CHAIN_INTERVAL)

    def _attack_window(self, seconds, tag=''):
        """★"连点窗口"（学爱达千）：窗口内每 SPIN_CLICK_INTERVAL 点一次普攻。

        为什么不是"点 n 下、固定 0.22s 一下"：演出/后摇会把贴着的点击**丢掉**（不排队），
        stride 猜错一次这几段连段就断了；窗口内连续点才接得上（心的 3A/2A 都用它）。"""
        start = time.time()
        n = 0
        self._check_combat_tolerant('连点窗口')
        while self._elapsed(start) < seconds:
            if self._over_budget():
                break
            self.click()
            n += 1
            time.sleep(self.SPIN_CLICK_INTERVAL)
        self.logger.debug(f'xrs {ME} {tag} 连点窗口 {seconds:.2f}s 共 {n} 下')
        return n

    def _poke_until(self, ready, timeout, interval=None, on_poke=None):
        """边点普攻边等 ready() 成立；成立立刻返回 True。到 timeout 返回 False（绝不卡死）。"""
        interval = interval or self.POKE_INTERVAL
        start = time.time()
        while True:
            if ready():
                return True
            if time.time() - start >= timeout:
                return False
            try:
                self.check_combat()
            except Exception:
                return False
            if on_poke is not None:
                try:
                    on_poke()
                except Exception:
                    pass
            self.click()
            time.sleep(interval)

    # ═══════ 大招/变身/交棒期间别让框架判"战斗结束" ═══════
    # 现象：屏幕上什么都看不见的那几秒（变身、变奏入场、R2），CombatCheck 会
    #   target lost ×3 → "target_enemy failed → break out of combat" → 整场战斗结束
    #   → on_combat_end 把状态机清空 → 下一场从开局重来。
    # 框架留了口子：CombatCheck.do_check_in_combat 先问当前角色的 skip_combat_check()。
    def _mark_busy(self, seconds=None):
        try:
            self.task._xrs_skip_check_until = time.time() + (seconds or self.SKIP_CHECK_AFTER_ULT)
        except Exception:
            pass

    def skip_combat_check(self):
        try:
            return time.time() < getattr(self.task, '_xrs_skip_check_until', 0)
        except Exception:
            return False

    # ═══════════ 固定顺序「直接切人」 ═══════════
    # 不用框架的 switch_next_char()：① 它按 get_switch_priority() 现场挑人，顺序会漂；
    #   ② 它一旦认不到队伍UI 就 raise_not_in_combat("not in_team while switching")
    #      → 直接结束整场战斗（旧队实战日志 19:23:18 / 19:24:22 两次就是这么被打断的）；
    #   ③ 它有几处"顺手补普攻"，会把要立刻走人的节奏拖乱。
    # 代价：框架的交接记账要自己补（全在 _handoff_to 里）。
    def _char_by_name(self, name):
        for c in getattr(self.task, 'chars', []) or []:
            if c is not None and getattr(c, 'name', None) == name:
                return c
        return None

    def _settle_with_attack(self, duration, attack=False):
        """等 duration 秒，期间保持点普攻（不干等，两边连段都不掉）。"""
        end = time.time() + min(float(duration), 3.0)
        while time.time() < end:
            if attack:
                self.click()
            time.sleep(min(0.1, max(0.0, end - time.time())))

    def _con_full(self):
        """协奏是否满：读到的值 ≥ CON_FULL_EPS 就算满（框架会把满环钳成 0.99）。"""
        try:
            val = self.get_current_con()
        except Exception:
            val = 0
        try:
            if self.is_con_full():
                return True
        except Exception:
            pass
        try:
            return float(val or 0) >= self.CON_FULL_EPS
        except Exception:
            return False


    def _ult_fired(self, timeout=1.0, poke=True):
        """按了 R 之后判断有没有真放出来。只认三件事：**R 自己的 CD 起来了** / 队伍UI消失 / 协奏值跳涨
        （协奏本来就满时不做跳涨判断，否则会误判成"放出来了"）。
        为什么加 CD 这一条：队伍UI消失会被弹窗/演出误报，而 CD 读数最直白 ——
        R 真放出去了，图标上就会开始走它的 CD（心 25s 级、雷主 25s、穗穗 ~20s）。"""
        try:
            before = con_of(self)
        except Exception:
            before = 0.0
        use_con = before < 0.95
        start = time.time()
        while time.time() - start < timeout:
            cd = self._cd_readout('liberation')
            if cd is not None and cd >= self.ULT_CD_MIN:
                return True
            try:
                if not self.task.in_team()[0]:
                    return True
            except Exception:
                pass
            if use_con:
                try:
                    if con_of(self) >= min(1.0, before + 0.12):
                        return True
                except Exception:
                    pass
            if poke:
                try:
                    self.click()  # 等待期间继续点普攻，别让角色站着
                except Exception:
                    pass
            # ★poke=False 时这一轮**一下都不点**：用户实测看到"强E 后还打了一下普攻才 R"，
            #   根源就是这里 —— 原来无论 poke 与否都在这里 click（雷主 R 之间被插了普攻）。
            time.sleep(0.1)
        return False

    def _ult_until_fired(self, tag, timeout=None, poke=True, poll=0.3):
        """按 R 直到放出来（能量够不够让游戏自己判断），放出来立刻停手。

        poke=True   ：边A边按 R（等待期间继续攒能量，适合"能量还没满要攒"的角色）
        poke=False  ：只按 R、不夹普攻（适合"上一步刚确认过能放"的场合 —— 视频里
                      雷主就是 强E → 立即接 R，中间不插普攻）。
        poll        ：两次按 R 之间等多久。**用户口径的"狂" = 0.2~0.4s 一次**，默认 0.3。"""
        timeout = self.ULT_TRY_TIMEOUT if timeout is None else timeout
        start = time.time()
        tries = 0
        while time.time() - start < timeout:
            self._mark_busy(6.0)
            tries += 1
            self.send_liberation_key()
            if self._ult_fired(poll, poke=poke):
                self.logger.info(f'xrs {ME} {tag} 已放出（按 R：第 {tries} 次，'
                                 f'{time.time() - start:.1f}s）')
                return True
            try:
                self.check_combat()
            except Exception:
                break
            if poke:
                self.click()
            time.sleep(0.2)
        self.logger.warning(f'xrs {ME} {tag} 边A边按 R {timeout:.0f}s 仍没放出来（共鸣能量不够）')
        return False

    def _fill_con(self):
        """离场前把协奏顶满（本轴里 →变奏X 的每一棒都要顶满才走）。只普攻。

        ★2026-10-06 15:4x 返工（三条，都有实测证据）：
          ① **去掉开头那句 `_wait_team_visible(5.0)`**。它是"读屏"判据，天生比动作晚
             （指南 §2.2：「读屏天生比动作晚」）—— 实测 `15-37-47` 那把：雷主大招 39.0s 起、
             录像里 42.0s 角色就能动了，而 `in_team()` 到 44.3s 才认到；
             心月狐 R2 那把更亏：`_fill_con` 等 5.0s + `_switch_out` 再等 4.0s 全白等，
             录像 71.0~76.0s 心月狐**站着不动**。
             现在改由调用方用「锚点 + 固定时长」先等收招（见 `_wait_ult_recover`）。
          ② **战斗判定改用 `_check_combat_tolerant()`**：指南 §2.6.2④ 明文
             「**绝不裸调 `check_combat()`**」—— 原来这里裸调，大招刚放完 target 瞬断时
             会抛 `not in combat`，把**整拍**截断（实测 15:38:31.521
             `Rover b8_rover_burst 执行异常：combat check not in combat → 直接交棒`，
             于是雷主 R 完那一下 a 和 Q 根本没发出去）。
          ③ 普攻改用 `_tap()`（10ms 的 `click()` 打不出来 —— 见 `_tap` 的注释）。
        """
        start = time.time()
        full = False
        timeout = getattr(self, 'FILL_CON_TIMEOUT_OVERRIDE', self.FILL_CON_TIMEOUT)
        while True:
            if self._con_full():
                full = True
                break
            if time.time() - start >= timeout or self._over_budget():
                break
            self._check_combat_tolerant('顶协奏')
            self._tap()
            time.sleep(0.15)
        self.logger.info(f'xrs {ME} 交棒前协奏={con_of(self):.2f} full={full} 用时{time.time() - start:.1f}s')
        if not full:
            self.logger.warning(
                f'xrs {ME} 协奏到上限还没满（{con_of(self):.2f}）→ 下一棒吃不到变奏；'
                f'反复出现就检查共鸣效率（视频要求：心117 / 雷主134 / 穗穗260+）')
        return full

    def _wait_con_full(self):
        """交棒前轮询协奏（必须在按切人键之前读：切走后能量环显示的是新角色的）。"""
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self._con_full():
                return True
            time.sleep(self.HANDOFF_CON_POLL)
        self.logger.info(f'xrs {ME} 交棒前协奏={con_of(self):.2f} 没满（读数只记录，给不给变奏由游戏按真值决定）')
        return False

    def _handoff_to(self, target, has_intro):
        """补上框架交接记账（自己按数字键切人会绕开它，不补 get_current_char() 会返回 None）。"""
        self.task.in_liberation = False
        try:
            self.switch_out(con_full=has_intro)
        except Exception:
            pass
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        elif not has_intro:
            # ★2026-10-06 15:5x bugfix（诊断日志抓到）：has_intro=False 时，
            #   目标身上上一次留下的 `intro_pending=True` **不会被清** ——
            #   实测 `15:47:51,504 Rover 交接给 Suisui has_intro=False target.has_intro=False
            #   target.intro_pending=True` → 紧接着 `15:47:52,451 Suisui take_intro → True`，
            #   也就是**白送了一次假变奏**（变奏的下一步动作会全错）。
            try:
                target.intro_pending = False
            except Exception:
                pass
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            try:
                self.task.add_freeze_duration(now, getattr(target, 'intro_motion_freeze_duration', 0.9), -100)
            except Exception:
                pass
            self.last_outro_time = now
        # ★诊断（只写日志，不改行为）：`intro`（变奏入场）一直读成 False，见交接 §11.4。
        #   这里把"交接那一刻"两个标记的取值钉下来，下一把日志就能看出是丢了还是被清了。
        self.logger.info(f'xrs {ME} 交接给 {getattr(target, "name", "?")} '
                         f'has_intro={has_intro} target.has_intro={getattr(target, "has_intro", None)} '
                         f'target.intro_pending={getattr(target, "intro_pending", None)}')

    def _hand_off(self, st, step, who):
        st['step'] = step
        st['next'] = who
        st['idle'] = 0

    def note_intro_handoff(self):
        self.intro_pending = True

    def take_intro(self):
        """本次入场是否带变奏；读完就清，避免下一轮误判。

        ★诊断：把两个标记的取值一起写日志（见交接 §11.4「intro 恒为 False」）。
        """
        intro = bool(self.has_intro or self.intro_pending)
        self.logger.info(f'xrs {ME} take_intro → {intro} '
                         f'(has_intro={self.has_intro} intro_pending={self.intro_pending})')
        self.intro_pending = False
        return intro

    # ─────────────── 必须覆盖的框架行为 ───────────────
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """本轴是固定顺序接力：状态里写着"该谁上"就谁上（MUST），其余人一律 NO。"""
        st = team_state(self.task)
        nxt = st.get('next')
        if nxt is None:
            return SwitchPriority.NORMAL
        return SwitchPriority.MUST if nxt == ME else SwitchPriority.NO

    def switch_other_char(self, allow_auto_combat=False):
        pass

    def healer_full_con_switch_locked(self):
        return False


    # ═══════════════════════════════════════════════════════════════════════
    #  v2.0 新增块 —— 合轴 / 状态驱动 / 重击 / 结构化日志
    #  设计依据：见 OKWW队伍轴开发工作流程.md §2.6（狂按窗口）与 §S1（轴提取）
    #  ⚠️ 本块追加在 shared_base.txt 之后 ⇒ 同名常量会覆盖前面 body 里的定义
    # ═══════════════════════════════════════════════════════════════════════

    # ── 合轴（mux）参数 ──────────────────────────────────────────────────
    MUX_WINDOW = 0.9            # ★合轴窗口：连段打完立刻狂按切换键，最多按这么久
    MUX_INTERVAL = 0.06         # 合轴狂按数字键的间隔（与 R_MASH_INTERVAL 同量级）
    MUX_SETTLE = 0.35           # 合轴切过去后等站稳（比正常切人的 0.55 短：合轴就是要抢时间）

    # ── 重击（Z = 长按左键）参数 —— 全部照抄 v1.2.8 真机验证值 ──────────
    HEAVY_HOLD = 5.5            # ★长按上限（实测高亮有时 2.8~3.2s 才亮 → 2.5s 会把真出手切掉）
    HEAVY_MIN_HOLD = 2.0        # ★"亮过又灭"要按住够久才算出手（防演出期间 HUD 抖动假阳）
    HEAVY_NO_LIGHT_HOLD = 2.5   # 全程没亮 → 只按这么久就松手（别让角色站着长按）
    HEAVY_POLL = 0.12           # 按住期间的采样间隔
    HEAVY_READY_WAIT = 3.0      # 等"重击高亮"出现的上限（边普攻边等）
    SKIP_SWITCH_WINDOW = 2.5    # ★`_skip` 的快速交棒窗口（开场必须"狂按切人"，不许停顿）
    TEAM_VISIBLE_POLL = 0.12    # 等队伍UI回来的轮询间隔（原来 0.25 + 每轮点一下，白花时间）
    ULT_SKIP_TEAM_WAIT = 6.0    # ★大招/变身演出期间"别等队伍UI"的时长
                                #   （演出时 UI 本来就不在，等它只会白等；实测白等 5s+4s）
    MASH_COMBAT_EVERY = 8       # ★狂按循环里每 N 次才做一次战斗判定
                                #   （实机实测：每次判定在 target 丢失时要 ~1.7s →
                                #    "狂按 R ×3（5.34s）" 就是这么来的；正常时只要 0.108s）

    # ── 状态驱动循环 ─────────────────────────────────────────────────────
    ATTACK_CAP_DEFAULT = 12     # 状态驱动普攻的默认上限（到点就走兜底，绝不空转）
    RISE_POLL = 0.12            # 等"某个信号由灭变亮"的轮询间隔

    def _perf(self, kind, **kv):
        """★结构化日志：一行一条、机器可解析。
        用途：攒数据后用脚本统计分布（例如"合轴第几次才切过去"→ 取 P95 定 MUX_WINDOW）。"""
        try:
            body = ' '.join(f'{k}={v}' for k, v in kv.items())
            self.logger.info(f'PERF {kind} who={ME} {body}')
        except Exception:
            pass

    # ── 状态驱动 + 有上限：替代"固定打 N 下" ───────────────────────────
    def _attack_until(self, ready, cap=None, tag=''):
        """★一直普攻直到 ready() 成立，或打满 cap 下。

        为什么必须有这个：**动作会被怪打断**，"打 3 下"这种计数式在被打断后必然错位。
        改成"状态驱动 + 有上限"后：
          · 状态已经达标 → 立刻停手（不会多打）
          · 被打断没达标 → 继续打，直到达标或到上限（这就是"重新检测"）
          · 到上限 → 返回 False，调用方走兜底（绝不空转）
        ready() 只允许用**硬信号**（资源模板 / 回路 / 图标由灭变亮），不许用颜色占比。
        """
        cap = int(cap or self.ATTACK_CAP_DEFAULT)
        start = time.time()
        n = 0
        for n in range(cap):
            if n and self._safe(ready):
                self._perf('until', tag=tag, hits=n, ok=1, t=f'{self._elapsed(start):.2f}')
                return True
            self._check_combat_tolerant(tag or 'attack_until')
            self.click()
            time.sleep(self.BETWEEN_ATTACK)
            if self._over_budget():
                break
        ok = self._safe(ready)
        self._perf('until', tag=tag, hits=n + 1, ok=int(bool(ok)),
                   t=f'{self._elapsed(start):.2f}')
        if not ok:
            self.logger.warning(f'xrs {ME} {tag} 普攻 {n + 1} 下仍未达标（到上限）→ 走兜底')
        return bool(ok)

    def _safe(self, fn):
        try:
            return bool(fn())
        except Exception:
            return False

    def _attacks(self, count, tag='连打'):
        """覆盖基础块的版本：①每下之间用**容忍版**战斗判定；②每下走**真按住**。

        ① 基础块用的是裸 `check_combat()` —— 演出/大招期间 target 瞬断会把**整场战斗掐掉**。
           v2 的每一拍都可能撞上演出，所以统一换成容忍版（连续 20 次才真的收场）。
        ② ★2026-10-06 15:5x 返工：基础块与 v2 原来都用 `self.click()`
           ＝ `BaseChar.click()` 写死 `down_time=0.01`（10ms）——
           实测「10ms 的按下沿落在普攻收招里**打不出来**」（录像 15-17-15 的 53.0~54.5s
           心月狐**站着不动**；楽山原文「task.click() 只按 10ms, 打不出来」）。
           改成 `self._tap()`（按住 A_TAP=0.06s 再松开）。
        """
        for _ in range(int(count)):
            if self._over_budget():
                return
            self._check_combat_tolerant(tag)
            self._tap()
            time.sleep(self.BETWEEN_ATTACK)

    def _rise(self, fn, timeout=3.0, tag=''):
        """★等"由灭变亮"（False→True）。

        铁律：入场时就已经亮的图标当凭据**必假阳**（心的一段大 lib1 在变奏入场时就亮）。
        所以先确认它现在是灭的，再等它亮。若一开始就亮 → 直接返回 True 但记 warn。
        """
        start = time.time()
        if self._safe(fn):
            self.logger.info(f'xrs {ME} {tag} 一开始就是亮（可能是残留，直接放行）')
            return True
        while self._elapsed(start) < timeout:
            if self._safe(fn):
                self._perf('rise', tag=tag, ok=1, t=f'{self._elapsed(start):.2f}')
                return True
            self._frame_once()
            time.sleep(self.RISE_POLL)
        self._perf('rise', tag=tag, ok=0, t=f'{self._elapsed(start):.2f}')
        return False

    # ── 补齐基础块引用但没定义的常量 ──────────────────────────────────────
    ULT_TRY_TIMEOUT = 6.0       # 「边A边按R」的时间上限（基础块 _ult_until_fired 用到）

    # ── 协奏环颜色：默认不钉（心月狐没有需要钉的形态环），Rover/Suisui 覆盖它 ──
    def _pin_ring_index(self):
        return None

    # ── 合轴（mux）───────────────────────────────────────────────────────
    def _mux_switch(self, target, window=None, tag='', settle=True):
        """★合轴切出 = 「连段打完 + 提前按 + 窗口内狂按切换键 + in_team() 确认」。

        为什么这么做（而不是"等一个固定秒数再切"）：
          · 合轴的触发信号是**画面动作相位**（"穗穗 A2 转身后退"/"雷主往后撤"/"心月狐尾巴甩到身后"）
            —— 这是 C 类软信号，按铁律**不能决定流程**，识别身体朝向在实机上也不可靠。
          · 但合轴两侧都是**数得清的连段**（a12 / a123）⇒ "切出时机"本身就是**硬信号**（我们自己数）。
          · 连段一打完就**立刻狂按目标位的数字键**：游戏会在"后摇的第一个合法帧"兑现这次切换，
            **合轴自动发生**（= 用对方的动作填掉自己的后摇）。
          · 落地用 `task.in_team()` 确认（下游链条接上了没）—— 也是硬信号。
          · 窗口用完还没切过去 → 返回 False，调用方**走保守分支**（作者说 ERE 与 a3a4 耗时几乎一样，
            所以放弃合轴不亏时间）。

        与 `_switch_out` 的区别：不要求协奏满（合轴是直切），窗口更短，站稳时间更短。
        """
        if target is None:
            return False
        window = self.MUX_WINDOW if window is None else window
        self._mark_busy(window + 1.5)
        start = time.time()
        n = 0
        ok = False
        while self._elapsed(start) < window:
            n += 1
            try:
                self.task.send_key(target.index + 1)
            except Exception as e:
                self.logger.debug(f'xrs {ME} 合轴按键异常 {e}')
            try:
                self._frame_once()
            except Exception:
                pass
            try:
                in_team, cur, _ = self.task.in_team()
                if in_team and cur == target.index:
                    ok = True
                    break
            except Exception:
                pass
            time.sleep(self.MUX_INTERVAL)
        self._perf('mux', tag=tag, target=target.index + 1, tries=n,
                   t=f'{self._elapsed(start):.2f}', ok=int(ok))
        if ok:
            if settle:
                self._settle_with_attack(self.MUX_SETTLE)
            self._handoff_to(target, self.take_intro())
        else:
            self.logger.warning(f'xrs {ME} 合轴 {tag} 窗口 {window:.2f}s 内没切过去 → 走保守分支')
        return ok

    # ── 重击（Z = 长按左键）──────────────────────────────────────────────
    #  ★2026-10-06 实机返工：原来的实现用"下游大招图标亮"当 done —— 会被**残留假阳**骗
    #    （心的 lib1 在变奏入场时就亮）→ 报告"已出手"其实没打出去 → 后面 R1/照世相全废。
    #    现在改成 v1.2.8 在真机上验证过的判据：**重击高亮"亮过 → 又灭"才算出手**。
    def _heavy_wait_lit(self, tag, per_try=3.0, tries=2, ready=None, cleared=None):
        """边普攻边等重击高亮出现（上限 per_try×tries）；带"竞态复查"。
        等的时候不能干站着 —— 资源是靠普攻攒的。"""
        ready = ready or self._heavy_ready
        for i in range(int(tries)):
            start = time.time()
            lit = False
            while time.time() - start < per_try:
                self._frame_once()              # ★先取新帧再判高亮（否则读的是同一张旧帧）
                if self._safe(ready):
                    lit = True
                    break
                self._check_combat_tolerant(f'{tag}·等高亮')
                self.click()                    # 攻击才攒资源
                time.sleep(0.15)
            if not lit and self._safe(ready):   # ★竞态复查：高亮可能正好在超时那一瞬间亮
                lit = True
            self.logger.info(f'xrs {ME} {tag} 第{i + 1}轮 高亮{"亮" if lit else "没亮（兜底长按）"} '
                             f'等了{self._elapsed(start):.1f}s')
            fired = self._heavy_hold(f'{tag} 第{i + 1}轮', cleared=cleared)
            # ★出手了就别再来一轮：只看 lit(h1/h2 高亮) 的话，
            #   照世相里 h1/h2 常年读不到 → lit 恒 0 → 白打第二发重击（实测 +5.3s，还挡掉了 R2）
            if lit or fired:
                return True
        return False

    def _heavy_hold(self, tag, hold_max=None, hold_min=None, no_light=None, ready=None,
                    cleared=None):
        """★长按左键（重击）。判据照抄 v1.2.8 真机验证过的版本：

            mouse_down → 每 0.12s 取新帧采样 h1/h2：
              · **亮过 → 又灭，且按住 ≥ HEAVY_MIN_HOLD(2.0s)** ⇒ 出手了，立刻松手
              · **全程没亮** ⇒ 只按 HEAVY_NO_LIGHT_HOLD(2.5s) 就松手（别让角色站着长按）
              · 按住上限 HEAVY_HOLD(5.5s)

        为什么上限是 5.5s 而不是 2.5s：实测高亮有时 **2.8~3.2s 才亮**，2.5s 上限会把真出手切掉。
        为什么"亮过又灭"要配 2.0s 下限：演出/大招期间 HUD 会抖，高亮可能先 True 后 False，
        不然会误判成"出手了"，实际只按了零点几秒 —— 打出来的是一下平A。
        """
        hold_max = self.HEAVY_HOLD if hold_max is None else hold_max
        hold_min = self.HEAVY_MIN_HOLD if hold_min is None else hold_min
        no_light = self.HEAVY_NO_LIGHT_HOLD if no_light is None else no_light
        ready = ready or self._heavy_ready

        try:
            self._frame_once()
            self.task.mouse_down()
        except Exception as e:
            self.logger.warning(f'xrs {ME} {tag} mouse_down 异常 {e}')
            return False
        seen = False
        fired = False
        start = time.time()
        try:
            while True:
                held = time.time() - start
                if held >= hold_max:
                    break
                self._check_combat_tolerant(f'{tag}·长按')
                self._frame_once()
                lit = self._safe(ready)
                if lit:
                    seen = True
                # ★额外的硬判据（学 楽山）：资源条被清空 = 这一下真出手了。
                #   比"图标亮灭"可靠 —— 楽山实测 hsin_h2 一帧都认不出来。
                if cleared is not None and held >= hold_min and self._safe(cleared):
                    fired = True
                    break
                if seen:
                    if (not lit) and held >= hold_min:   # ★亮过又灭 + 按住够久 = 真出手
                        fired = True
                        break
                elif cleared is None and held >= no_light:   # 全程没亮且没有清空判据 → 早松手
                    break
                time.sleep(self.HEAVY_POLL)
        finally:
            try:
                self.task.mouse_up()
            except Exception:
                pass
        held = time.time() - start
        time.sleep(0.15)
        self._perf('heavy', tag=tag, held=f'{held:.2f}', lit=int(seen), ok=int(fired))
        if fired and seen:
            why = '已出手（亮过又灭）'
        elif fired:
            why = '已出手（资源条清空）'
        elif not seen:
            why = '未确认（全程没亮）'
        else:
            why = '未确认（到上限）'
        self.logger.info(f'xrs {ME} {tag} 长按{held:.1f}s → {why}')
        return fired

    # ── ★「真按住再松开」的普攻（学 楽山 `tap()`）────────────────────────
    # 为什么不能用 `self.click()`：`BaseChar.click()` 写死 `down_time=0.01` —— 10ms 的
    # 按下沿在这个游戏里**打不出普攻**（楽山真机结论：「task.click() 只按 10ms, 打不出来」；
    # 我方 2026-10-06 15-17-15 那把逐帧连拍也拍到"心月狐站着不动"）。
    # 凡是要"打得出来"的普攻都必须走这个。
    A_TAP = 0.06                # 一下普攻的按住时长（楽山 A_TAP=0.06）

    def _tap(self, hold=None):
        """一次"真按住再松开"的普攻。`try/finally` 保证一定松开（否则会变成一直按住=重击）。"""
        hold = self.A_TAP if hold is None else hold
        try:
            self.task.mouse_down()
            time.sleep(hold)
        finally:
            try:
                self.task.mouse_up()
            except Exception:
                pass

    # ── ★大招收招：锚点 + 固定时长（指南 §2.2 / §2.3）────────────────────
    # §2.2 原文：「**最稳的是「识别到的事件当锚点 + 从锚点起算固定时长」**」，
    #        并且「**读屏天生比动作晚**」。
    # §2.3 原文：大招收招属于「**1. 打不断**（按键被游戏吃掉）」⇒ **只能等**，
    #        而且「等待期间**不要发任何会 activate 的输入**」。
    # ⇒ 所以这里就是一个纯 sleep：**锚点由调用方给**（＝R 刚刚被确认出手的那一刻），
    #   时长用真机录像量出来。**不要**在这里等 `in_team()`（那是读屏）。
    ULT_RECOVER_DEFAULT = 3.0   # 通用收招时长（实测雷主/穗穗 ~2.8~3.0s）

    def _wait_ult_recover(self, seconds=None, tag=''):
        """等大招收招过去。**纯计时、期间一个输入都不发**（§2.2 + §2.3）。"""
        seconds = self.ULT_RECOVER_DEFAULT if seconds is None else float(seconds)
        self._mark_busy(seconds + 1.0)
        time.sleep(seconds)
        self.logger.info(f'xrs {ME} {tag} 大招收招等待 {seconds:.1f}s（锚点+固定时长，期间不发输入）')

    # ── ★大招之后「狂按切人」（用户口径 2026-10-06 15:26）────────────────
    # 「穗穗二段 R 后可狂按切人至雷主」
    # 依据 §2.6.1：游戏**不缓存**按键 ⇒ 不是"按一次然后等演出结束"，而是
    # **一直按到切过去为止**（总有一次正好落在演出刚结束那一帧）。
    # 实测（15-26-01 那把）：原来先 `_wait_team_visible()` → 白等满 4.0s
    # （日志 15:26:21.270 放大招 → 25.284 "等了 4.0s 队伍UI都没回来"）。
    ULT_MASH_SWITCH_WINDOW = 6.0    # 狂按切人的总窗口（要盖过 ~4.5s 的大招演出）
    ULT_MASH_SWITCH_GAP = 0.10      # 狂按间隔（比 SWITCH_KEY_INTERVAL=0.12 略密）

    def _switch_to_index(self, index, timeout=None, gap=None):
        """覆盖基础块：多 timeout/gap —— 大招后"狂按切人"要更长的窗口、更密的间隔。

        ⚠️ 每轮仍然保留 `self.click()`：它除了"别让角色发呆"，还是模拟器
        （`battle_sim.py`）推进剧本事件的唯一入口（`click()` → `sim.tick()` → 结算 `lib_end`）；
        去掉它会让"演出结束"这件事在模拟器里永远不发生 → 窗口白跑满（实测 +4.7s/次）。
        """
        timeout = self.SWITCH_TIMEOUT if timeout is None else timeout
        gap = self.SWITCH_KEY_INTERVAL if gap is None else gap
        start = time.time()
        n = 0
        while time.time() - start < timeout:
            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                break
            if in_team and current_index == index:
                self.logger.info(f'xrs {ME} 切人确认：按了 {n} 下、用时 {time.time() - start:.2f}s')
                self._settle_with_attack(self.SWITCH_SETTLE)
                return True
            n += 1
            self.task.send_key(index + 1)
            self.click()
            time.sleep(gap)
        self.logger.warning(f'xrs {ME} 切人窗口 {timeout:.1f}s 内按了 {n} 下都没切过去')
        return False

    def _switch_out(self, skip_con=False, mash=False):
        """按状态里的 next 固定顺序直切（覆盖基础块：多一个 `mash`）。

        mash=True（大招刚放完）＝**先不等队伍UI**，直接"狂按数字键直到 in_team() 认到目标"。
        """
        st = team_state(self.task)
        who = st.get('next')
        target = self._char_by_name(who)
        if target is None:
            self.logger.warning(f'xrs 状态里的接棒人 {who} 找不到 → 交回框架选人')
            return self.switch_next_char()
        if mash:
            window, gap = self.ULT_MASH_SWITCH_WINDOW, self.ULT_MASH_SWITCH_GAP
        else:
            window, gap = None, None
        self._mark_busy((window or self.SWITCH_TIMEOUT) + 1.0)
        if not mash:
            self._wait_team_visible()                  # 大招演出期间按键会被吞，先等 UI 回来
        has_intro = False if skip_con else self._wait_con_full()
        ok = self._switch_to_index(target.index, timeout=window, gap=gap)
        if not ok:
            for attempt in range(2):
                self.logger.warning(f'xrs 直切 {who} 失败 → 就地重试第 {attempt + 1} 次')
                self._wait_team_visible(self.RETRY_TEAM_WAIT)
                self._settle_with_attack(0.25)
                if self._switch_to_index(target.index):
                    ok = True
                    break
            if not ok:
                self._shot(f'xrs_switch_fail_{who}')   # ★留证：切人失败那一瞬间的界面
                self.logger.warning(f'xrs 直切 {who} 三次都没成功（不结束战斗，下一拍再试）')
                return False
        self.logger.info(f'xrs 直切到 {who} (slot{target.index + 1}) has_intro={has_intro}')
        self._handoff_to(target, has_intro)
        return True

    # ── 覆盖基础块：等队伍UI回来时轮询更快、且等待期间不发输入 ──
    def _wait_team_visible(self, timeout=None):
        """等"队伍UI回来"（大招演出/变身期间 in_team()[0] 是 False）。

        2026-10-06 返工：基础块是 `sleep(0.25)` + **每轮点一下普攻**。
        但演出期间按键本来就会被吞 —— 那一下点击纯属白花时间；
        而且 0.25s 的轮询粒度会让"UI 刚回来"这件事平均晚 0.12s 才被发现。
        用户点名「74s 雷主还顿了一会」→ 这里改成 0.12s 轮询、等待期间**不发输入**。"""
        if time.time() < getattr(self, '_skip_team_wait_until', 0.0):
            # ★刚放完大招/变身：演出期间队伍UI**本来就不在**，等它 = 白等
            #   （实测 `交棒前等了 5.0s 队伍UI都没回来` → 用户看到「二段r后没能及时切回雷主」）
            return False
        timeout = self.TEAM_WAIT_TIMEOUT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            try:
                if self.task.in_team()[0]:
                    return True
            except Exception:
                return False
            time.sleep(self.TEAM_VISIBLE_POLL)
        self.logger.warning(f'xrs 交棒前等了 {timeout}s 队伍UI都没回来，照常切人')
        return False

    # ── 覆盖基础块的 `_spam_r_until_fired`：狂按循环里**别每次都做战斗判定** ──
    def _spam_r_until_fired(self, tag, window=None, poke=False, poll=None):
        """★狂按 R 直到"真出手"。与基础块同逻辑，只改一处：**战斗判定节流**。

        实机实测（2026-10-06 那把）：
          · 正常时 33 次 / 3.56s = **0.108s 一次** ✔（与 v1 一致）
          · 变身/大招演出 + target 丢失时 **3 次 / 5.34s = 1.78s 一次** ✘
        根因是每次迭代都调 `check_combat()`，而它在 target 丢失时要重试/重锁定（~1.7s）。
        ⇒ 改成每 MASH_COMBAT_EVERY(8) 次才判一次，并且循环首尾各判一次兜底。
        """
        window = self.R_MASH_WINDOW if window is None else window
        poll = self.R_MASH_INTERVAL if poll is None else poll
        start = time.time()
        n = 0
        fired = False
        while self._elapsed(start) < window:
            if self._over_budget():
                break
            if n % self.MASH_COMBAT_EVERY == 0:
                self._check_combat_tolerant('狂按R')
            n += 1
            try:
                self.send_liberation_key()
            except Exception as e:
                self.logger.debug(f'xrs {ME} 狂按 R 异常 {e}')
            try:
                self.task.next_frame()
            except Exception:
                pass
            try:
                if not self.task.in_team()[0]:      # 队伍UI消失 = 演出开始 = 出手
                    fired = True
                    break
            except Exception:
                pass
            if poke:
                self.click()
            time.sleep(poll)
        if fired:
            self._record('liber')
            self._mark_ult_fired()
        self._perf('mashR', tag=tag, n=n, t=f'{self._elapsed(start):.2f}', ok=int(fired))
        self.logger.info(f'xrs {ME} {tag} 狂按 R ×{n}（{self._elapsed(start):.2f}s）→ '
                         f'{"已出手（队伍UI消失）" if fired else "窗口到上限还没出手"}')
        return fired

    def _mark_ult_fired(self):
        """刚放出大招/变身 → 记一段时间内"别等队伍UI"。

        理由（实测）：大招/变身演出期间 **队伍UI本来就不在**，
        `_wait_team_visible` 等它只会白等 —— 日志里出现过
        `交棒前等了 5.0s 队伍UI都没回来` + `...4.0s`，9 秒全浪费在等一个
        "演完才会出现"的东西上。用户看到的就是"穗穗二段r后未能及时切回雷主"。
        """
        self._skip_team_wait_until = time.time() + self.ULT_SKIP_TEAM_WAIT

    # ── 由 BEATS 表派生：推进到下一拍 ────────────────────────────────────
    def _advance(self, st):
        """按 BEATS 表的顺序推进到下一拍（表是唯一来源，代码里不再手写"下一棒是谁"）。"""
        try:
            cur = st.get('step')
            order = list(BEAT_ORDER)
            i = order.index(cur) if cur in order else 0
            nxt = order[(i + 1) % len(order)]
            # 跑完 b9 就切到循环相位
            if cur == order[-1] and st.get('phase') != 'loop':
                st['phase'] = 'loop'
                self.logger.info(f'xrs {ME} 启动轴跑完 → 进入循环轴')
            st['step'] = nxt
            st['next'] = BEAT_WHO[nxt]
            st['idle'] = 0
            self.logger.info(f'xrs {ME} 交棒 {cur} → {nxt}（下一棒 {st["next"]}，相位 {st.get("phase")}）')
        except Exception as e:
            self.logger.warning(f'xrs {ME} _advance 异常 {e} → 交回框架')
            st['next'] = None

    def _phase(self, st):
        return 'loop' if st.get('phase') == 'loop' else 'q'

    def _beat_note(self, step):
        """把 BEATS 表里这一拍的契约信息取出来（用于日志，方便对账）。"""
        return BEAT_NOTE.get(step, {})

    # ── 覆盖基础块里的两处（基础块是 v1 的写法，v2 的 step 名不同）──────
    def _skip(self, st):
        """这一拍不是我的 → 把场子交出去。

        ★2026-10-06 返工（用户口径：「开场必须狂按切人穗穗，不允许停顿」）：
        原来这里直接走 `_switch_out()`，它开头是 `_wait_team_visible()`（最长 4s）——
        实机 log 里开场就停 **3.0 秒**（`13:19:41.751 直切到 Hsin` → `13:19:44.736 直切到 Suisui`）。
        现在改成：**先走"快速交棒"（狂按目标位数字键，窗口 SKIP_SWITCH_WINDOW）**，
        失败才退回常规 `_switch_out()`。

        看门狗：连续 3 次没人接手 = 状态卡死 → **从 BEATS 表的第一拍 + 循环相位重开**。"""
        who = st.get('next')
        if who == ME:
            st['next'] = None
            who = None
        st['idle'] = st.get('idle', 0) + 1
        if st['idle'] >= 3:
            first = BEAT_ORDER[0]
            st.update({'step': first, 'phase': 'loop', 'next': BEAT_WHO[first], 'idle': 0})
            who = BEAT_WHO[first]
            self.logger.warning(
                f'xrs 状态卡死（连续 3 次轮不到任何人）→ 从循环轴的 {first} 重开')
        target = self._char_by_name(who) if who else None
        if target is not None:
            if self._mux_switch(target, window=self.SKIP_SWITCH_WINDOW, tag='skip'):
                return True
            self.logger.warning(f'xrs {ME} 快速交棒到 {who} 没成功 → 退回常规切人')
        return self._switch_out()

    def on_combat_end(self, chars):
        try:
            setattr(self.task, STATE_ATTR, dict(INITIAL_STATE))
            self.logger.info('xrs v2 战斗结束 → 状态重置（下一场从穗穗首发开始）')
        except Exception:
            pass