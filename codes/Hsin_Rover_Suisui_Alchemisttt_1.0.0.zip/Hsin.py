# -*- coding: utf-8 -*-
r"""心（1号位 / 导电）—— 「心雷穗」轮椅轴（BV15gYF6GEPF）

本文件由 D:\Hermes-data\tools\okww-custom-char\build_xrs_team.py 生成；
改时间常数请直接改本文件（或改生成器后重新生成三份，保持公共块一致）。
"""
import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, Elements, SwitchPriority

STATE_ATTR = '_xrs_state'
ME = 'Hsin'

INITIAL_STATE = {'step': 'hsin_open', 'phase': 'open', 'next': 'Hsin', 'idle': 0}


def team_state(task):
    """队伍共享状态（挂在 task 上，三名角色各持一份同名代码也能看到同一个进度）。"""
    st = getattr(task, STATE_ATTR, None)
    if not isinstance(st, dict):
        st = dict(INITIAL_STATE)
        setattr(task, STATE_ATTR, st)
    return st


def con_of(char):
    try:
        return float(char.get_current_con() or 0)
    except Exception:
        return 0.0


class Hsin(BaseChar):
    """心（1号位 / 导电）—— 「心雷穗」轮椅轴（参考视频 BV15gYF6GEPF）

    本轴里心**每轮只上场一次**，但这一次要走完视频 第7~11 拍：
        Q(声骸) → A4 → 强化重击·步红尘 → R（一段大·转相/变身）
        → [启动 3A / 循环 2A] → E → 强E（万阙连衡，进「统御众机」）
        → 3A → 闪 → 2A → 终结重击·临寰宇 → R2（万阙垂天·最终大招）
        → 顶满协奏 → 变奏穗穗
    和旧队「心卜穗」最大的不同：中间**不再插卜灵**（旧队她是分两次上场），
    所以 v1/v2 合并成一次 `hsin_main`，中间不切人。

    机制（官方口径）：
      · 应世相（人形）：攻击攒【应世心】→ 满时长按左键 = 强化重击·步红尘 → 解锁 R（转相/变身）
      · 照世相（白毛岁主）：攻击攒【照世心】→ 满时短按E = 强化E·万阙连衡（进统御众机）
        → 统御众机下攻击消耗【照世心】→ 耗尽时长按左键 = 终结重击·临寰宇 → 解锁 R2
      · 视频原话：3A 用来攒效应层数、2A 用来消耗效应层数（所以启动/循环这里不一样）
      · 大招结束后**不要释放一技能**，直接变奏穗穗（一技能会结算全部效应层数）
    """
    MY_STEPS = ('hsin_open', 'hsin_main')

    # ── 可调参数 ──
    A4_ATTACKS = 4             # 「打普攻A4」= 打到第 4 段
    HEAVY_HOLD = 5.5           # ★长按上限（学爱达千 E2_ANIM_HOLD=5.5：打出来就立刻退出，
                               #   只有失败的轮次才多等 —— "抬高上限几乎不花时间"）
    HEAVY_POLL = 0.12          # ★长按期间采样 h1/h2 的间隔（爱达千 E2_POLL=0.12）
    HEAVY_MIN_HOLD = 2.0       # ★亮过但按住不足 2.0s 不算出手（演出期间 HUD 会抖，爱达千 E2_HEAVY_MIN_HOLD）
    HEAVY_NO_LIGHT_HOLD = 4.5  # ★2.5→4.5s：照世相里我们**看不到高亮**（没有可用模板），此时长按
                               #   只能靠"按够时间"来触发 —— 参考包实测"重击要按住约 3.8 秒才出手"，
                               #   2.5s 常常还没出手就松手了（19:54 那把临寰宇全程没亮、R2 图标也没亮）
    E_POLL = 0.30              # ★拍8 攒资源期间每 0.30s 看一次 h1/h2（别每次都看，免得把连段拖散）
    E_PHASE_ATTACKS = 4          # ★拍8 固定节奏：引爆之后连打几下（攒照世心）再按强化E
    E_WAIT_FULL = 8.0          # ★拍8 打满【照世心】等它满的上限
    A_WINDOW_3A = 1.20         # （旧）拍9「3A」的连点窗口时长
    A_WINDOW_2A = 0.85         # ★拍9「2A」的连点窗口时长
    HEAVY_WAIT_V1 = 3.0        # 节拍7：等强化重击解锁（h1/h2 亮）的上限，等时继续普攻
    HEAVY_WAIT_V2 = 3.0        # 节拍9：等终结重击·临寰宇解锁的上限
    TRANSFORM_SETTLE = 0.6     # 引爆/落地之后站定的时间
    TRANSFORM_WAIT = 1.0       # ★变身(转相)后的"小等一下"（不再盲等 2.5s —— 剩下的交给狂按 E）
    E_PRESS_INTERVAL = 0.3     # ★"狂按"的定义（用户口径：0.2~0.4s 一次）
    E_SPAM_UNTIL = 5.0         # （保留）狂按 E 的总上限
    E_TO_ENHANCED_E = 0.9      # ★旧队实机实测：视频里两次 E 相隔 ≈1.0s（0.35s 时第二下还在第一下动作里）
    E_ROUNDS = 4               # ★兜底轮数：每轮「打满一套 3A → 连点 2 下 E」；到上限才放弃
    E_HOLD = 0.35              # 强E 连续请求时每次按住 0.35s（同时覆盖短按/长按机制）
    E_TO_NEXT = 0.4            # 两次按 E 之间（旧队实测两次 E 要 ≈1.0s，按太密第二下会落在第一下动作里）
    E_PHASE_TIMEOUT = 2.0      # 强E 连续请求的总时长（视频实机 ≈1.6s）
    V2_OPEN_ATTACKS = 3        # 启动轴「3A」（攒效应层数）
    V2_LOOP_ATTACKS = 2        # 循环轴「2A」（消耗效应层数）
    V2_COMBO = 3               # 「再打3A」
    V2_AFTER_DODGE = 2         # 「2A加重击」
    WAIT_BEFORE_SUISUI = 0.5   # 视频提示：太快变奏穗穗会触发不到她的被动
    ULT_TRY_TIMEOUT = 8.0      # 一段大能量攒得慢（边A边按R，8s 是实测值）
    LIB2_WAIT = 3.0            # ★等 R2 图标(lib2)亮的上限；不亮就补一轮重击（见 _run_axis 拍10）

    VISIT_CAPS = {'hsin_open': 3.0, 'hsin_main': 55.0}   # 心这次长上场（第7~11拍）给足预算
    #  ★v1.0.2：45→55s —— 节拍7 现在允许「重击→试R」3 轮（每轮最多 3s 等高亮 + 1.65s 长按 + 5s 试R）

    # ══════════════════════════ 主流程 ══════════════════════════
    def do_perform(self):
        st = team_state(self.task)
        if st['step'] not in self.MY_STEPS:
            return self._skip(st)

        st['idle'] = 0
        self._visit_t0 = time.time()
        self.VISIT_CAP = self.VISIT_CAPS.get(st['step'], 12.0)

        if st['step'] == 'hsin_open':
            # 视频启动轴第一行是穗穗的 3A-E → 心开场什么都不做，直接交棒
            self.logger.info('xrs 心 开局：视频里这里不动作 → 直接交棒穗穗（穗穗 3A-E）')
            st['phase'] = 'open'
            self._hand_off(st, 'suisui_open', 'Suisui')
            return self._switch_out(skip_con=True)

        intro = self.take_intro()
        if intro:
            self._settle_with_attack(0.5)     # 变奏入场动画期间按键会被吞 → 先站稳
        else:
            self.logger.warning('xrs 心 这次没吃到变奏入场（本轴她该由雷主的延奏带进来，'
                                '吃不到就拿不到电髓/全队攻击加成）')
        t0 = time.time()
        self._run_axis(st)
        st['phase'] = 'loop'                  # 下一轮起进循环版（心的 2A-E-强E）
        self._hand_off(st, 'suisui_loop', 'Suisui')
        self.logger.info(f'xrs 心 本轮(hsin_main) 用时 {time.time() - t0:.2f}s '
                         f'图标{self._icons()} 协奏={con_of(self):.2f}')
        self._switch_out()

    def _run_axis(self, st):
        """心的整段轴（视频 第7~11 拍），全程站在场上不换人。"""
        loop_phase = (st.get('phase') == 'loop')
        n_before_e = self.V2_LOOP_ATTACKS if loop_phase else self.V2_OPEN_ATTACKS
        self.logger.info(f'xrs 心 入场 图标{self._icons()} 阶段={st.get("phase")} '
                         f'（Q-A4-强化重击-R → {n_before_e}A-E-强E → 3A-闪-2A-重击 → R2 → 变奏穗穗）')
        self._echo()                                        # Q 声骸
        self._attacks(self.A4_ATTACKS)                      # A4
        # 节拍7 的收尾是 R（转相/变身）：重击没打出去 → R 解锁不了 → 后面拍8~11 全废。
        #   所以这里改成「重击 → 试 R」最多 3 轮（中间补普攻攒资源），R 一放出去立刻往下走。
        for rnd in range(3):
            self._heavy_until(f'强化重击·步红尘(第{rnd + 1}轮)', tries=1, per_try=self.HEAVY_WAIT_V1,
                              done=lambda: bool(self._icons().get('lib1')))
            # ★v1.2 步骤2：强化重击之后**立刻狂按 R**（学爱达千：两步合并 + 演出边界判定）
            if self._spam_r_until_fired('一段大招（转相/变身）', window=self.ULT_TRY_TIMEOUT):
                break
            self.logger.warning(f'xrs 心 强化重击后一段大招没出来（第{rnd + 1}轮）→ 补普攻再来一轮')
            self._attacks(3)
        self._mark_busy(8.0)
        # ★16:54 实测：变身动画还没走完就按 E，游戏全吞（CD读数一直是 -0.01）→
        #   变身后多等一会儿再进照世相的动作（期间保持点普攻，攻击本身也在攒资源）
        self._settle_with_attack(self.TRANSFORM_WAIT)
        self._shot('xrs_hsin_after_transform')              # 留证：变身之后（照世心/霆心域）

        # ── 照世相：3A/2A → E → 强E（进统御众机）──
        self._t_e = time.time()
        self._e_phase(n_before_e)
        self._t_e = time.time() - self._t_e
        self._shot('xrs_hsin_after_e')
        time.sleep(self.TRANSFORM_SETTLE)

        # ── 3A ＋闪（同时）→ 2A → 终结重击·临寰宇 → R2 ──
        # ★教学原文：「a，a，a 与闪同时按，之后再接两次 a」
        self._combo_3a_dodge_2a('拍9')
        # （拍9 的重击在下面 _heavy_until(..., skip_wait=True) 里直接按，不再等高亮）
        t_heavy2 = time.time()
        # ★下游信号 = lib2（R2）亮 → 临寰宇真打出去了 → 立刻停，不要再等第二个 3s（17:31 那把白等 4.5s）
        self._heavy_until('终结重击·临寰宇', tries=2, per_try=self.HEAVY_WAIT_V2,
                          done=lambda: bool(self._icons().get('lib2')), skip_wait=True)
        # ★v1.0.8：R2 的图标(lib2)在 `_press_ult` 里是**硬门槛**（不亮不按 —— 按错会让她变回原形态）。
        #   但"临寰宇这一下没真打出去 → lib2 不亮 → 整拍丢掉"也是不能接受的。
        #   兜底做法：先等 lib2 亮（≤LIB2_WAIT，期间保持普攻）；还不亮就**再补一轮「3A-闪-2A-重击」**
        #   （= 重做条件，而不是闭着眼睛按 R），然后才去按 R2。
        if not self._wait_lib('lib2', self.LIB2_WAIT):
            self.logger.warning('xrs 心 R2 图标还没亮 → 补一轮「3A-闪-2A-重击」再来（不闭眼按 R）')
            self._attacks(self.V2_COMBO)
            self._dodge()
            self._attacks(self.V2_AFTER_DODGE)
            self._heavy_until('终结重击·临寰宇(补轮)', tries=1, per_try=self.HEAVY_WAIT_V2,
                              done=lambda: bool(self._icons().get('lib2')), skip_wait=True)
        # ★R2 必须**图标亮才按**：照世相里乱按 R 会让心切回原形态（本轴明令禁止的动作）。
        #   19:53 那把就是 lib2 一直没亮、我们还是狂按了 24 次 R → 用户看到"按了 R 切换了形态"。
        if self._icons().get('lib2'):
            self._spam_r_until_fired('二段大招（最终大招 R2）', window=self.ULT_TRY_TIMEOUT)
        else:
            self.logger.warning('xrs 心 二段大招(R2) 图标还没亮 → **不按 R**（按了会让心切回原形态，'
                                '本轴禁止）→ 直接交棒穗穗')
        self.logger.info(f'xrs 心 各拍耗时：变身后强E {self._t_e:.1f}s / 临寰宇→R2 {time.time() - t_heavy2:.1f}s')
        self._settle_with_attack(self.WAIT_BEFORE_SUISUI)
        self._fill_con()                                    # →变奏穗穗

    # ══════════════════════════ 心的专用判据 ══════════════════════════
    def _icons(self):
        """心的四个模板（只写日志 / 当强E与重击的解锁门槛用）。

        ★四个模板共用**同一张新帧**（`_frame_once()` 会现取一帧），否则就是拿旧帧在猜。"""
        frame = self._frame_once()

        def hit(label):
            try:
                return bool(self.task.find_one(label, threshold=0.7, frame=frame))
            except Exception:
                return False
        return {
            'lib1': hit(Labels.hsin_lib1),   # 一段大招（转相）可用
            'lib2': hit(Labels.hsin_lib2),   # 二段大招（万阙垂天）可用
            'h1': hit(Labels.hsin_h1),       # 强化重击可用
            'h2': hit(Labels.hsin_h2),
        }

    def _heavy(self, tag=''):
        """长按普攻 = 强化重击（学爱达千的重击控制）。

        ★v1.2：长按上限 1.5→5.5s，期间每 0.12s 采样 h1/h2：
          · **亮过 → 又灭 = 出手了**，立刻松手（这才是"打完马上接下一个动作"）；
          · 但必须按住 ≥ HEAVY_MIN_HOLD(2.0s) 才认那一下"亮过"—— 演出/大招期间 HUD 是乱的，
            高亮可能先 True 后 False（爱达千注释里踩过一模一样的坑），不然会误判成"出手了"，
            实际只按住零点几秒，打出来的是一下平A；
          · 全程没亮过 → 只按 1.0s 就松（别让角色站在那长按，用户看到的是"卡顿/僵直"）。"""
        self.task.mouse_down()
        seen = False
        fired = False
        start = time.time()
        try:
            while True:
                el = time.time() - start
                if el >= self.HEAVY_HOLD:
                    break
                self.check_combat()
                self._frame_once()               # ★先取新帧再采样（否则读的是同一张旧帧 → 亮灭都不变）
                lit = self._heavy_ready()        # ★先采样再判断（采样要在判断之前）
                if lit:
                    seen = True
                if seen:
                    # 亮过 → 等它灭（灭 = 重击出手）
                    if (not lit) and el >= self.HEAVY_MIN_HOLD:
                        fired = True
                        break
                elif el >= self.HEAVY_NO_LIGHT_HOLD:
                    # 一直没亮：再给 2.5s，还不亮才认为"这一下没资源"松手
                    break
                time.sleep(self.HEAVY_POLL)
        finally:
            self.task.mouse_up()
        time.sleep(0.15)
        self.logger.info(f'xrs 心 {tag} 长按{time.time() - start:.1f}s '
                         f'{"（亮过又灭=已出手，提前松手）" if fired else ""}'
                         f'{"（全程没亮，早松手）" if (not seen) else ""} 图标{self._icons()}')


    def _wait_lib(self, key, timeout):
        """等某个大招图标亮（期间保持普攻，不干等）；亮返回 True。"""
        return self._poke_until(lambda: bool(self._icons().get(key, False)), timeout)

    def _heavy_ready(self, frame=None):
        """强化重击是否已解锁（h1 或 h2 亮）。传 frame 就用那张帧，否则现取一张新的。"""
        if frame is None:
            frame = self._frame_once()

        def hit(label):
            try:
                return bool(self.task.find_one(label, threshold=0.7, frame=frame))
            except Exception:
                return False
        return hit(Labels.hsin_h1) or hit(Labels.hsin_h2)

    def _heavy_wait_unlock(self, tag, timeout):
        """（保留）等强化重击解锁再长按；现在主流程用的是 `_heavy_until`。"""
        start = time.time()
        while time.time() - start < timeout:
            if self._heavy_ready():
                self.logger.info(f'xrs 心 {tag} 强化重击已解锁(h高亮) 用时{time.time() - start:.1f}s → 长按释放')
                break
            self.check_combat()
            self.click()
            time.sleep(0.15)
        else:
            self.logger.info(f'xrs 心 {tag} 等了{timeout:.1f}s 高亮没亮 → 固定长按兜底')
        return self._heavy(tag)

    # ═══════════ 强化重击：等到亮再按 + 多轮重试（用户口径：亮着长按就一定按得出来） ═══════════
    # 实测（16:43 那把）：我们只等了 3s 就长按 —— 那一刻 h1/h2 还没亮、重击没打出去，
    #   而 h1 直到 9 秒后才亮（资源是慢慢攒上来的）→ 后面的大招当然解锁不了、按不出来。
    # 做法：每轮「边A边等 h1/h2 亮（最长 per_try 秒）→ 长按」；亮着按（用户说必出）就返回；
    #   没亮也兜底按一次（游戏没资源时会忽略，无害），然后补普攻/继续等，进下一轮。
    #   轮数有上限，绝不卡死。
    def _heavy_until(self, tag, tries=2, per_try=3.0, done=None, skip_wait=False):
        """等【重击】可用(h1/h2 高亮)再长按；打完用 `done()` 复核**下游信号**，成立就停。

        ★v1.0.7（17:31 那把实测）：`tries=2` 原来会把同一招打两遍 —— 临寰宇第 1 轮其实已经打出去了
        （第 2 轮开始前 `图标` 里 lib2 已经 True = R2 已解锁），可代码还在"等高亮 + 长按"，
        白等 3s + 白长按 1.5s，用户看到的就是"强化重击后没立刻放二段大"。
        所以加 `done`：**下游信号成立就立刻停**（临寰宇 → lib2 亮；步红尘 → lib1 亮）。
        另外补一次"竞态复查"：日志里出现过 `高亮没亮（兜底长按）` 但同一行 `图标` 里 h2 是 True
        —— 高亮是在等待超时那一瞬间才亮的，所以超时后再看一次，亮着就按"亮"处理。"""
        for i in range(tries):
            lit = False
            start = time.time()
            if skip_wait:
                # ★照世相（拍9）：h1/h2 在这段根本认不到（日志 `高亮没亮` ×11、`全程没亮` ×8），
                #   继续等只是白等 3.2s → 直接按（教学口径：3A+闪→2A 打完"能量就满了"，接着重击）
                self.logger.info(f'xrs 心 {tag} 第{i + 1}轮 不等高亮（照世相没有可用模板）→ 直接长按')
                self._heavy(f'{tag} 第{i + 1}轮')
                if done is not None and done():
                    self.logger.info(f'xrs 心 {tag} 第{i + 1}轮 长按后 下游信号已成立 → 停')
                    return True
                continue
            while time.time() - start < per_try:
                self._frame_once()           # ★先取新帧再判高亮（"高亮没亮 等了3.2s" 就是旧帧害的）
                if self._heavy_ready():
                    lit = True
                    break
                self.check_combat()
                self.click()                 # 攻击才攒资源（等的时候别站着）
                time.sleep(0.15)
            if not lit and self._heavy_ready():      # ★竞态复查
                lit = True
            self.logger.info(f'xrs 心 {tag} 第{i + 1}轮 高亮{"亮" if lit else "没亮（兜底长按）"} '
                             f'等了{time.time() - start:.1f}s 图标{self._icons()}')
            self._heavy(f'{tag} 第{i + 1}轮')
            if lit:
                return True
            if done is not None:
                if done():
                    self.logger.info(f'xrs 心 {tag} 第{i + 1}轮 长按后 下游信号已成立'
                                     f'（R2/变身 已解锁）→ 不再重复长按，直接进下一拍')
                    return True
        return False


    # ═══════════ 照世相的 E → 强E（就是「心有强化E而不用」那个坑） ═══════════
    # 16:54 实测：心变身之后我们只等了 0.6s、打了 3 下就按 E，结果 E 按了 4 次、
    #   CD读数一直是 -0.01（一次都没生效 —— 全被变身动画吞掉了）→ 用户看到
    #   「心有强化E而不用」。旧队（心卜穗）里这一步之所以没踩坑，是因为她的变身(R)
    #   发生在上一段、E 阶段是下一个"变奏入场"之后，中间隔了十几秒。
    # 做法：E 不再"按完就走" —— 每轮「打 n 下 → 短按 E → 等 0.5s 读 CD」，
    #   读到 CD 起来（心 E 的 CD ≈12s）才算真放出去了，然后进强E（连按 E 进统御众机）；
    #   没生效就再打几下重试（上限 E_ROUNDS 轮，绝不卡死）。
    def _e_phase(self, n_before_e):
        """照世相（拍8，面板「3A - E - 强E」）：**固定节奏**走完，不依赖任何图标/冷却判读。

        ★为什么改回固定节奏（20:05 日志铁证）：
          · 心的 E **CD 读数经常是负数**（-0.02 / -0.35 / -0.76）—— 那是"没读出数字"，
            不是"没放出去"。我加的那套"按完复核 CD"因此产生**假失败**：明明放出去了也判没生效
            → 一次引爆被按成 3 次，整段 拍8 花掉 6.5s、只连打 3 下（照世心根本没攒上）✗
          · 【照世相】的 h1/h2 高亮模板认不到（日志里全是 False），E 图标高亮又会在
            CD 18~19s 还在走的时候误报"可用" → 又一次白按。
          · 用户口径：**普通E 与强化E 是两条独立冷却**，"打满 3A 加 E"照打即可
            （普通E 进 CD 不影响强化E 重新解锁）→ 节奏对就行，不用判读。
        固定节奏：nA（起手）→ E（普通·引爆）→ 等 0.9s → 再连打 4 下（攒照世心）
                  → E（强化E·万阙连衡）→ 收工。
        """
        t0 = time.time()
        if n_before_e:
            self._attack_chain(n_before_e, tag='拍8 起手')
        self._press_e('E(共鸣技能/引爆)', hold=self.E_HOLD)
        time.sleep(self.E_TO_ENHANCED_E)
        self._attack_chain(self.E_PHASE_ATTACKS, tag='拍8 攒照世心')
        self._press_e('E(强化E·万阙连衡)', hold=self.E_HOLD)
        time.sleep(self.E_TO_NEXT)
        self.logger.info(f'xrs 心 拍8 收工（固定节奏：{n_before_e}A → E → '
                         f'{self.E_PHASE_ATTACKS}A → E，用时{self._elapsed(t0):.1f}s）')
        return True


    def _enhanced_e(self):
        """强E（强化共鸣技能·万阙连衡）：连续请求，游戏自己当门槛。

        照世相是「攻击攒【照世心】→ 满时短按E 才能放强化E」→ 每次先补一下普攻再按 E
        （E → A → E 的节奏），而不是连着空按 E。视频实机这一步的 E 输入持续 ≈1.6s。"""
        t0 = time.time()
        n = 0
        while time.time() - t0 < self.E_PHASE_TIMEOUT:
            if self._over_budget():
                break
            self.click()
            n += 1
            self._press_e(f'强E 第{n}次', hold=self.E_HOLD)
            time.sleep(self.E_TO_NEXT)
        self.logger.info(f'xrs 心 强E 阶段结束 共按{n}次 用时{time.time() - t0:.1f}s '
                         f'CD读数={self._cd_readout()} 图标{self._icons()}')

    def _press_ult(self, tag, lib_key, timeout=None, poll=0.5):
        """按 R 开大（一段大·变身 / 二段大 R2）。

        ★v1.0.2 改法：**不再"图标亮才按"**（hsin_lib1 会假亮/卡住不灭 —— 实测 16:43 那把
        图标一直 True，我们按了 8.4s 却一次都没放出去）。现在：
          · 一段大（变身）：直接按（时机不对时游戏会忽略，无害），
            用「图标灭 / R 自己的 CD 起来了」确认放出去了 → **立刻停手**（防误触二段大变回原形态）；
          · 二段大（R2）：**没亮坚决不按**（按错会变回原形态，这条保留旧队的保险）。"""
        timeout = self.ULT_TRY_TIMEOUT if timeout is None else timeout
        start = time.time()
        fired = False
        tries = 0
        while time.time() - start < timeout:
            self._mark_busy(6.0)
            if lib_key == 'lib2' and not self._icons().get('lib2', False):
                self.check_combat()
                self.click()
                time.sleep(0.2)
                continue
            tries += 1
            self.send_liberation_key()
            time.sleep(poll)
            if not self._icons().get(lib_key, False):
                fired = True
                break
            cd = self._cd_readout('liberation')
            if cd is not None and cd >= self.ULT_CD_MIN:
                fired = True
                break
            self.check_combat()
            self.click()
            time.sleep(0.2)
        if lib_key == 'lib1' and not fired:
            self.logger.warning(f'xrs 心 {tag} 按了{tries}次都没确认放出去 → 硬按一次兜底')
            self.send_liberation_key()
        elif lib_key == 'lib2' and not fired:
            self.logger.warning(f'xrs 心 {tag} 图标没亮 → 不按（避免误触变回原形态）')
        self.logger.info(f'xrs 心 {tag} {"已放出" if fired else "未放出"} 用时{time.time() - start:.1f}s '
                         f'按了{tries}次 R的CD={self._cd_readout("liberation")} 图标{self._icons()}')
        return fired

    # ═══════════════════════════════════════════════════════════════════════
    #  以下为「心雷穗」三名角色共用的骨架（由 build_xrs_team.py 统一生成）
    #  设计对照：固定顺序接力 / 自己按数字键切人 / 状态机写在 task._xrs_state 上
    # ═══════════════════════════════════════════════════════════════════════

    # ─────────────────────── 可调参数（公共） ───────────────────────
    BETWEEN_ATTACK = 0.22       # 普攻间隔
    DODGE_SETTLE = 0.25         # 闪避之后的落地缓冲
    ECHO_SETTLE = 0.2           # 按 Q（声骸）之后等动作
    FILL_CON_TIMEOUT = 3.5      # 交棒前顶满协奏的时间上限（Rover 在自己类里覆盖成 2.0）
    E_SETTLE = 0.35             # 一次 E 之后等动作
    TEAM_WAIT_TIMEOUT = 4.0     # 交棒前等"队伍UI回来"的上限（大招演出期间它是 False）
    RETRY_TEAM_WAIT = 2.5       # ★重试时只等 2.5s：'队伍UI没回来'基本都是游戏在演出/加载，久等没意义
    SWITCH_TIMEOUT = 2.0        # 单程切人最长尝试时间
    SWITCH_KEY_INTERVAL = 0.12  # 连按数字键的间隔
    SWITCH_SETTLE = 0.55        # 切过去之后等站稳（0.50/0.52 会把下一棒起手吞掉）
    SETTLE_ATTACK_INTERVAL = 0.42
    HANDOFF_CON_WAIT = 0.8      # 交棒前轮询协奏是否满的上限（必须在按切人键之前读）
    HANDOFF_CON_POLL = 0.1
    POKE_INTERVAL = 0.12        # 连点地板：再密会被吞/变成下落攻击
    POKE_READ_EVERY = 3         # 每 3 下普攻才读一次屏（≈0.36s，节流）
    SKIP_CHECK_AFTER_ULT = 5.0  # 大招/变身/交棒之后多久内不做"战斗结束"判定
    CON_FULL_EPS = 0.90         # ok-ww 把满环钳成 0.99、读数有 ±5% 抖动 → ≥0.90 就算满
    ULT_CD_MIN = 15.0           # R 的 CD 读数 ≥15s ⇒ "R 真放出去了"（三人大招 CD 都是 20s 级）
    VISIT_CAP = 12.0            # 兜底预算（没在 VISIT_CAPS 里配的段）
    intro_pending = False       # 持久标记：reset_state() 会把 has_intro 清成 False
    intro_motion_freeze_duration = 0.9

    # ══════════════ 本段站场的硬时间预算（抗干扰 + 不挨打） ══════════════
    def _over_budget(self):
        """本段站场时间是否已超过预算（超了就放弃剩余动作直接交棒）。"""
        cap = getattr(self, 'VISIT_CAP', 12.0)
        t0 = getattr(self, '_visit_t0', None)
        if t0 is None or time.time() - t0 < cap:
            return False
        self.logger.warning(f'xrs {ME} 本段站场已达上限 {cap:.0f}s → 放弃剩余动作直接交棒（抗干扰）')
        self._visit_t0 = time.time()      # 重置，避免同一段反复刷同一行日志
        return True

    # ══════════════════════════ 动作原语 ══════════════════════════
    def _attacks(self, count):
        for _ in range(int(count)):
            if self._over_budget():
                return
            self.check_combat()
            self.click()
            time.sleep(self.BETWEEN_ATTACK)

    def _dodge(self):
        try:
            self.task.send_key(self.task.key_config.get('Dodge Key', 'lshift'))
            time.sleep(self.DODGE_SETTLE)
        except Exception as e:
            self.logger.debug(f'xrs 闪避异常 {e}')

    def _press_e(self, tag, hold=0.05):
        """按一下 E（共鸣技能），**不看 resonance_available()**。

        为什么去掉门槛：resonance_available() = has_cd() = OCR 读技能图标上的冷却数字，
        第一下 E 之后它必然是 False → 会把整段强E 判成"不可用"跳过（旧队实战日志原文：
        `xbs 心 强E 不可用(E在冷却)→跳过`）。识别类判据只配写日志，不配决定流程。
        hold>0.06s 时 send_key 会走 keyDown→sleep→keyUp，一次调用同时覆盖短按/长按两种机制。
        """
        key = 'e'
        try:
            key = self.get_resonance_key()
        except Exception:
            pass
        try:
            self.task.send_key(key, down_time=max(hold, 0.02))
            time.sleep(0.05)
        except Exception as e:
            self.logger.debug(f'xrs {ME} {tag} 按键异常 {e}')
        self.logger.info(f'xrs {ME} {tag} ← 按下 E(hold={hold:.2f}s) CD读数={self._cd_readout()}')

    def _cd_readout(self, box='resonance'):
        """读一次技能冷却读数（只写日志 / 当"刚按的技能真放出来了"的复核）。"""
        try:
            return round(float(self.task.get_cd(box)), 2)
        except Exception:
            return None

    def _echo(self):
        """Q = 声骸技能。"""
        try:
            if self.echo_available():
                self.click_echo(time_out=0)
                time.sleep(self.ECHO_SETTLE)
            else:
                self.logger.info(f'xrs {ME} 声骸不可用，跳过 Q')
        except Exception as e:
            self.logger.debug(f'xrs {ME} 声骸异常 {e}')

    def _shot(self, name):
        """留一张实战截图（随 OK-WW-log.zip 的 screenshots/ 回来）。

        【电涌】【照世心】【霆心域】这类资源条没有模板图，只能留证人工看 —— 别拿
        不可靠的识别结果去卡流程。"""
        try:
            self.task.screenshot(name)
        except Exception as e:
            self.logger.debug(f'xrs 截图 {name} 失败 {e}')

    # ═══════ 学 爱达千 那条轴：\u300c边A边等条件成立\u300d（不是站着干等） ═══════
    # ═══════════ 判定层（学爱达千 Aemeath.py）═══════════
    # 为什么不再用 get_cd() 的 CD 读数当"技能真放出去了吗"的凭据：
    #   OCR 有 ~1s 渲染延迟（按完立刻读是旧值），演出/特效糊住时整段读不到 → 判定又晚又错。
    # 改成：① 自己记"什么时候按过/放出去了"（_record / _since）；
    #       ② 时间口径用框架的 time_elapsed_accounting_for_freeze（**自动扣掉演出冻结时间**）；
    #       ③ "大招出手"用**队伍UI消失**判定（爱达千注释原文：演出期间的按键会被带过边界，
    #          演出一结束就兑现）—— 所以要狂按，而不是"按一次然后等读数"。
    LIB_CD = 25.0                 # 大招 CD（本队三人都是 20~25s 级）
    R_MASH_INTERVAL = 0.06        # 狂按 R 的间隔（爱达千 R2_KEY_INTERVAL=0.05 / EF_SPAM_INTERVAL=0.08）
    R_MASH_WINDOW = 3.5           # 狂按 R 的窗口长度（到点没出手就照常往下走）
    SPIN_CLICK_INTERVAL = 0.12    # "连点窗口"里的点击间隔（爱达千同名常量同值）
    A_CHAIN_INTERVAL = 0.33       # ★连续普攻的点击间隔：**按游戏普攻动画的自然节奏**。
                                  #   原来 0.16s 太密（日志里"连打 46 下"其实大半被吞，
                                  #   连段起不来 → 照世心/能量都攒不满）。参考包爱达千的连点窗口
                                  #   也是 4~5 下用 1.45s ≈ 0.33s/下。
    E_TAP = 0.05                  # 短按 E 的默认按压时长（共鸣技能）
    E_READY_CD = 0.6              # E 的 CD 读数 ≤0.6s（且 >0.05）⇒ "有 E 可放"
    E_MIN_ATTACKS = 3             # ★拍8 最少连打几下（松松的兜底，防止 0 下就收工）
    E_MIN_TIME = 1.5              # ★拍8 最少时长（用户口径：有 E 就赶紧放，别被"最少时长"拖住）
    E_PRESS_GAP = 0.35            # ★两次按 E 之间至少隔这么久（防同一个窗口重复按；别设太大，用户要"有E就放"）
    E_SPAM_MAX = 8                # 拍8 里"有E就放E"最多放几次（防呆）

    def _marks(self):
        m = getattr(self, '_xrs_marks', None)
        if m is None:
            m = {}
            self._xrs_marks = m
        return m

    def _record(self, key):
        """记一笔"这个动作我做过/这个技能放出去了"（自记账，供后面推算可用性）。"""
        self._marks()[key] = time.time()
        return self._marks()[key]

    def _elapsed(self, t):
        """从 t 到现在，**扣除演出冻结时间**（框架 API；拿不到就退回原始差值）。"""
        try:
            return self.time_elapsed_accounting_for_freeze(t)
        except Exception:
            return time.time() - t

    def _since(self, key):
        t = self._marks().get(key)
        return None if t is None else self._elapsed(t)

    def _lib_by_record_ready(self):
        """按自记账推算"现在能不能放大招"（没放过 / CD 已过 → 能）。只写日志用。"""
        s = self._since('liber')
        return s is None or s >= self.LIB_CD

    def _spam_r_until_fired(self, tag, window=None, poke=False, poll=None):
        """★狂按 R 直到"真出手"（学爱达千 `spam_r_e_until_lib`）。

        判定 = **队伍UI消失**（= 大招演出开始 = 出手了）。演出期间的按键会被"带过边界"，
        演出一结束就兑现 —— 所以狂按才对，而不是"按一次再等 CD 读数"（读数慢 ~1s）。
        出手或到窗口上限都停，两种情况都写日志（绝不卡死）。"""
        window = self.R_MASH_WINDOW if window is None else window
        poll = self.R_MASH_INTERVAL if poll is None else poll
        start = time.time()
        n = 0
        fired = False
        while self._elapsed(start) < window:
            if self._over_budget():
                break
            # 战斗判定用**容忍版**：演出/大招期间 target 会瞬断，单次失败不该结束整场
            #   （真·不在战斗时连续 20 次 ≈1.5s 后照样收场，不会像 19:12 那把空跑 55s）
            self._check_combat_tolerant('狂按R')
            n += 1
            try:
                self.send_liberation_key()
            except Exception as e:
                self.logger.debug(f'xrs {ME} 狂按 R 异常 {e}')
            try:
                self.task.next_frame()          # 每发一次键取一帧（参考包同款做法）
            except Exception:
                pass
            try:
                if not self.task.in_team()[0]:  # 队伍UI消失 = 演出开始 = 出手
                    fired = True
                    break
            except Exception:
                pass
            if poke:
                self.click()
            time.sleep(poll)
        if fired:
            self._record('liber')
        self.logger.info(f'xrs {ME} {tag} 狂按 R ×{n}（{self._elapsed(start):.2f}s）→ '
                         f'{"已出手（队伍UI消失）" if fired else "窗口到上限还没出手"}')
        return fired

    COMBAT_MISS_LIMIT = 20    # ★连续这么多次战斗判定失败才真的收场（演出/大招期间 target 会瞬断）

    def _check_combat_tolerant(self, tag=''):
        """战斗判定的**容忍版**：单次失败不结束战斗，连续 COMBAT_MISS_LIMIT 次才抛。

        为什么必须有：`task.check_combat()` 一旦判失败就 `raise_not_in_combat` → **整场战斗结束**。
        我们新加的狂按循环每 0.06s 查一次（比框架自己的频率高得多），演出/大招/变身期间
        target 瞬间丢失就会被命中 → 用户看到的"刚变奏到心，没过一会战斗就结束了"就是这么来的。
        容忍版：短暂瞬断继续按，真·不在战斗（连续 20 次 ≈ 1.5s）才让框架收场。"""
        try:
            self.check_combat()
            self._combat_miss = 0
        except Exception as e:
            self._combat_miss = getattr(self, '_combat_miss', 0) + 1
            if self._combat_miss >= self.COMBAT_MISS_LIMIT:
                self.logger.warning(f'xrs {ME} 战斗判定连续失败 {self._combat_miss} 次 → 收场（{e}）')
                raise
            self.logger.debug(f'xrs {ME} 战斗判定失败第{self._combat_miss}次（容忍中）{e}')

    def _frame_once(self):
        """取**最新**帧。

        ★关键（19:16 实测）：框架的画面只在有人调用 `task.next_frame()` 时才更新 ——
        我们的长按/等待循环里没人调，`find_one` 就一直在读**同一张旧帧**：
        表现是"高亮永远不变"（长按撞到 5.5s 上限才松、"等3.2s 高亮没亮"其实是读旧帧）。
        参考包（爱达千）的每个轮询都带一句 `self.task.next_frame()`，必须补上。"""
        try:
            f = self.task.next_frame()
            if f is not None:
                return f
        except Exception:
            pass
        try:
            return self.task.frame
        except Exception:
            return None

    def _press_e_verified(self, tag='', tries=3, hold=None, gap=0.4):
        """★按 E **并复核真的放出去了**（CD 读数跳起来才算），没生效就重按。

        用户口径 + 日志证据（19:58 那把）：我们连按 3 次 E，**只有 1 次真生效**
        （CD 读数 19.99 ✓），另两次读到的是 -0.0 / 19.19（无效）。
        屏幕上就是"3A 打完了却不点 E / 不点强E" —— 因为按了的那几次被动作吞掉了。"""
        hold = self.E_TAP if hold is None else hold
        for i in range(tries):
            if self._over_budget():
                return False
            before = self._cd_readout()
            self._press_e(f'{tag} 第{i + 1}次', hold=hold)
            time.sleep(0.35)                     # 等 CD 数字渲染出来（~0.3s）
            after = self._cd_readout()
            if after is not None and after > 0.05 and (before is None or after > before + 0.5):
                self.logger.info(f'xrs 心 {tag} 已生效（CD {before} → {after}）')
                return True
            self.logger.info(f'xrs 心 {tag} 第{i + 1}次没生效（CD {before} → {after}）→ 重按')
            time.sleep(gap)
        self.logger.warning(f'xrs 心 {tag} 连按 {tries} 次都没确认生效')
        return False

    def _e_ready_now(self, tag=''):
        """"有 E 就放 E" 的判据：E 的 CD 读数已好，**或** E 图标正在发光（高亮=可用）。

        用户口径（19:4x）："3ae强e 那段，也要检测有 e 就放 e，不然浪费时间"。
        用两个信号取或：① CD 读数 ≤ E_READY_CD；② 框架的颜色判定 box_highlighted('resonance')
        （E 图标上的白色高亮 —— 这是"技能可用"最直接的画面信号，不受 OCR 延迟影响）。"""
        # ★CD 读数 -0.0 / 0.0 绝不能当"E 好了"：那只是"图标上没有数字"，
        #   可能是读数没画出来/读失败（19:50 那把就是被它骗了：1.6 秒内"有E就放"两次 → 误判拍8 收工）
        cd = self._cd_readout()
        if cd is not None and 0.05 < cd <= self.E_READY_CD:
            return True, f'CD读数={cd}'
        try:
            if self.task.box_highlighted('resonance'):     # E 图标白色高亮 = 最可靠的"可用"
                return True, '图标高亮'
        except Exception:
            pass
        return False, ''

    def _attack_chain(self, n, tag=''):
        """★连续 n 下普攻：**一口气打完**（中间不插闪避、不插任何检查）。

        用户口径（19:31）："3A 被拆分了，非常不连贯，浪费时间" ——
        上一版每下点击之间还夹了战斗判定/取帧，连段被打散。这里只发点击。"""
        if not n:
            return
        self._check_combat_tolerant(tag or '连打')
        for _ in range(int(n)):
            self.click()
            time.sleep(self.A_CHAIN_INTERVAL)
        self.logger.debug(f'xrs 心 {tag} 连打 {int(n)} 下')

    def _combo_3a_dodge_2a(self, tag=''):
        """★教学原文：「a，a，a **与闪同时按**，之后再接两次 a」。

        3 下普攻，**第 3 下按完立刻闪避**（闪避取消 3A 的后摇 —— 这是省时间的关键），
        再补 2 下普攻。**不用固定窗口等**：等窗口＝把后摇完整吃下来，
        强化形态的倒计时里白白烧掉一秒多（用户："a3 后摇太浪费时间导致掉 buff"）。"""
        self._check_combat_tolerant('3A+闪')
        t0 = time.time()
        for i in range(3):
            self.click()
            if i == 2:
                self._dodge()                       # ★与第 3 下**同一帧**发出（中间不再 sleep）
            else:
                time.sleep(self.A_CHAIN_INTERVAL)   # ★按普攻动画的自然节奏（0.33s）
        time.sleep(self.DODGE_SETTLE)               # 闪避落地缓冲，再补 2A（否则 2A 落在闪避动作里）
        for _ in range(2):
            self.click()
            time.sleep(self.A_CHAIN_INTERVAL)
        self.logger.info(f'xrs 心 3A+闪+2A 走完（{self._elapsed(t0):.1f}s，'
                         f'3A+闪同帧 → 缓冲{self.DODGE_SETTLE}s → 2A）')

    def _attack_window(self, seconds, tag=''):
        """★"连点窗口"（学爱达千）：窗口内每 SPIN_CLICK_INTERVAL 点一次普攻。

        为什么不是"点 n 下、固定 0.22s 一下"：演出/后摇会把贴着的点击**丢掉**（不排队），
        stride 猜错一次这几段连段就断了；窗口内连续点才接得上（心的 3A/2A 都用它）。"""
        start = time.time()
        n = 0
        self._check_combat_tolerant('连点窗口')
        while self._elapsed(start) < seconds:
            if self._over_budget():
                break
            self.click()
            n += 1
            time.sleep(self.SPIN_CLICK_INTERVAL)
        self.logger.debug(f'xrs {ME} {tag} 连点窗口 {seconds:.2f}s 共 {n} 下')
        return n

    def _poke_until(self, ready, timeout, interval=None, on_poke=None):
        """边点普攻边等 ready() 成立；成立立刻返回 True。到 timeout 返回 False（绝不卡死）。"""
        interval = interval or self.POKE_INTERVAL
        start = time.time()
        while True:
            if ready():
                return True
            if time.time() - start >= timeout:
                return False
            try:
                self.check_combat()
            except Exception:
                return False
            if on_poke is not None:
                try:
                    on_poke()
                except Exception:
                    pass
            self.click()
            time.sleep(interval)

    # ═══════ 大招/变身/交棒期间别让框架判"战斗结束" ═══════
    # 现象：屏幕上什么都看不见的那几秒（变身、变奏入场、R2），CombatCheck 会
    #   target lost ×3 → "target_enemy failed → break out of combat" → 整场战斗结束
    #   → on_combat_end 把状态机清空 → 下一场从开局重来。
    # 框架留了口子：CombatCheck.do_check_in_combat 先问当前角色的 skip_combat_check()。
    def _mark_busy(self, seconds=None):
        try:
            self.task._xrs_skip_check_until = time.time() + (seconds or self.SKIP_CHECK_AFTER_ULT)
        except Exception:
            pass

    def skip_combat_check(self):
        try:
            return time.time() < getattr(self.task, '_xrs_skip_check_until', 0)
        except Exception:
            return False

    # ═══════════ 固定顺序「直接切人」 ═══════════
    # 不用框架的 switch_next_char()：① 它按 get_switch_priority() 现场挑人，顺序会漂；
    #   ② 它一旦认不到队伍UI 就 raise_not_in_combat("not in_team while switching")
    #      → 直接结束整场战斗（旧队实战日志 19:23:18 / 19:24:22 两次就是这么被打断的）；
    #   ③ 它有几处"顺手补普攻"，会把要立刻走人的节奏拖乱。
    # 代价：框架的交接记账要自己补（全在 _handoff_to 里）。
    def _char_by_name(self, name):
        for c in getattr(self.task, 'chars', []) or []:
            if c is not None and getattr(c, 'name', None) == name:
                return c
        return None

    def _switch_to_index(self, index):
        """按数字键切到指定队伍位置，直到 in_team 确认切过去（超时就放弃，不抛异常）。"""
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                break
            if in_team and current_index == index:
                self._settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            time.sleep(self.SWITCH_KEY_INTERVAL)
        return False

    def _settle_with_attack(self, duration, attack=False):
        """等 duration 秒，期间保持点普攻（不干等，两边连段都不掉）。"""
        end = time.time() + min(float(duration), 3.0)
        while time.time() < end:
            if attack:
                self.click()
            time.sleep(min(0.1, max(0.0, end - time.time())))

    def _con_full(self):
        """协奏是否满：读到的值 ≥ CON_FULL_EPS 就算满（框架会把满环钳成 0.99）。"""
        try:
            val = self.get_current_con()
        except Exception:
            val = 0
        try:
            if self.is_con_full():
                return True
        except Exception:
            pass
        try:
            return float(val or 0) >= self.CON_FULL_EPS
        except Exception:
            return False


    def _ult_fired(self, timeout=1.0, poke=True):
        """按了 R 之后判断有没有真放出来。只认三件事：**R 自己的 CD 起来了** / 队伍UI消失 / 协奏值跳涨
        （协奏本来就满时不做跳涨判断，否则会误判成"放出来了"）。
        为什么加 CD 这一条：队伍UI消失会被弹窗/演出误报，而 CD 读数最直白 ——
        R 真放出去了，图标上就会开始走它的 CD（心 25s 级、雷主 25s、穗穗 ~20s）。"""
        try:
            before = con_of(self)
        except Exception:
            before = 0.0
        use_con = before < 0.95
        start = time.time()
        while time.time() - start < timeout:
            cd = self._cd_readout('liberation')
            if cd is not None and cd >= self.ULT_CD_MIN:
                return True
            try:
                if not self.task.in_team()[0]:
                    return True
            except Exception:
                pass
            if use_con:
                try:
                    if con_of(self) >= min(1.0, before + 0.12):
                        return True
                except Exception:
                    pass
            if poke:
                try:
                    self.click()  # 等待期间继续点普攻，别让角色站着
                except Exception:
                    pass
            # ★poke=False 时这一轮**一下都不点**：用户实测看到"强E 后还打了一下普攻才 R"，
            #   根源就是这里 —— 原来无论 poke 与否都在这里 click（雷主 R 之间被插了普攻）。
            time.sleep(0.1)
        return False

    def _ult_until_fired(self, tag, timeout=None, poke=True, poll=0.3):
        """按 R 直到放出来（能量够不够让游戏自己判断），放出来立刻停手。

        poke=True   ：边A边按 R（等待期间继续攒能量，适合"能量还没满要攒"的角色）
        poke=False  ：只按 R、不夹普攻（适合"上一步刚确认过能放"的场合 —— 视频里
                      雷主就是 强E → 立即接 R，中间不插普攻）。
        poll        ：两次按 R 之间等多久。**用户口径的"狂" = 0.2~0.4s 一次**，默认 0.3。"""
        timeout = self.ULT_TRY_TIMEOUT if timeout is None else timeout
        start = time.time()
        tries = 0
        while time.time() - start < timeout:
            self._mark_busy(6.0)
            tries += 1
            self.send_liberation_key()
            if self._ult_fired(poll, poke=poke):
                self.logger.info(f'xrs {ME} {tag} 已放出（按 R：第 {tries} 次，'
                                 f'{time.time() - start:.1f}s）')
                return True
            try:
                self.check_combat()
            except Exception:
                break
            if poke:
                self.click()
            time.sleep(0.2)
        self.logger.warning(f'xrs {ME} {tag} 边A边按 R {timeout:.0f}s 仍没放出来（共鸣能量不够）')
        return False

    def _fill_con(self):
        """离场前把协奏顶满（本轴里 →变奏X 的每一棒都要顶满才走）。只普攻。"""
        start = time.time()
        full = False
        # 顶协奏之前必须先等"队伍UI回来"：大招演出/变身期间 UI 隐藏，那时读协奏只能读到 0.00
        self._wait_team_visible(5.0)
        # ★注意：生成器是「body + SHARED」拼接 → SHARED 里的定义会**覆盖** body 里的同名常量，
        #   所以角色想改自己的顶协奏上限要用 xxx_OVERRIDE（本轴：雷主 2.0s、其余用 SHARED 的 3.5s）
        timeout = getattr(self, 'FILL_CON_TIMEOUT_OVERRIDE', self.FILL_CON_TIMEOUT)
        zero_since = None
        while True:
            if self._con_full():
                full = True
                break
            # ★协奏读数一直 0.00 = 元素环读不到（特效糊住/特效期间），
            #   这种情况顶到底也没用（日志里出现 10 次，每次白等 2~3.5s）→ 1.5s 就放弃并如实记日志
            if con_of(self) <= 0.02:
                zero_since = zero_since or time.time()
                if time.time() - zero_since >= 1.5:
                    self.logger.warning('xrs 协奏读数一直是 0.00（环读不到）→ 不再干等，直接交棒'
                                        '（给不给变奏由游戏按真值决定）')
                    break
            else:
                zero_since = None
            if time.time() - start >= timeout or self._over_budget():
                break
            self.check_combat()
            self.click()
            time.sleep(0.15)
        self.logger.info(f'xrs {ME} 交棒前协奏={con_of(self):.2f} full={full} 用时{time.time() - start:.1f}s')
        if not full:
            self.logger.warning(
                f'xrs {ME} 协奏到上限还没满（{con_of(self):.2f}）→ 下一棒吃不到变奏；'
                f'反复出现就检查共鸣效率（视频要求：心117 / 雷主134 / 穗穗260+）')
        return full

    def _wait_con_full(self):
        """交棒前轮询协奏（必须在按切人键之前读：切走后能量环显示的是新角色的）。"""
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self._con_full():
                return True
            time.sleep(self.HANDOFF_CON_POLL)
        self.logger.info(f'xrs {ME} 交棒前协奏={con_of(self):.2f} 没满（读数只记录，给不给变奏由游戏按真值决定）')
        return False

    def _handoff_to(self, target, has_intro):
        """补上框架交接记账（自己按数字键切人会绕开它，不补 get_current_char() 会返回 None）。"""
        self.task.in_liberation = False
        try:
            self.switch_out(con_full=has_intro)
        except Exception:
            pass
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            try:
                self.task.add_freeze_duration(now, getattr(target, 'intro_motion_freeze_duration', 0.9), -100)
            except Exception:
                pass
            self.last_outro_time = now

    def _wait_team_visible(self, timeout=None):
        """等"队伍UI回来"（大招演出/变身期间 in_team()[0] 是 False）。

        日志实证：切人那一刻队伍UI认不到 → 框架直接结束整场战斗。所以切人前先把它等回来。"""
        timeout = self.TEAM_WAIT_TIMEOUT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            try:
                if self.task.in_team()[0]:
                    return True
            except Exception:
                return False
            try:
                self.click()      # 等待期间保持输入，别发呆
            except Exception:
                pass
            time.sleep(0.25)
        self.logger.warning(f'xrs 交棒前等了 {timeout}s 队伍UI都没回来，照常切人')
        return False

    def _switch_out(self, skip_con=False):
        """按状态里的 next 固定顺序直切（不用框架 switch_next_char）。"""
        st = team_state(self.task)
        who = st.get('next')
        target = self._char_by_name(who)
        if target is None:
            self.logger.warning(f'xrs 状态里的接棒人 {who} 找不到 → 交回框架选人')
            return self.switch_next_char()
        self._mark_busy(4.0)
        self._wait_team_visible()                      # 大招演出期间按键会被吞，先等 UI 回来
        has_intro = False if skip_con else self._wait_con_full()
        ok = self._switch_to_index(target.index)
        if not ok:
            for attempt in range(2):
                self.logger.warning(f'xrs 直切 {who} 失败 → 就地重试第 {attempt + 1} 次')
                self._wait_team_visible(self.RETRY_TEAM_WAIT)
                self._settle_with_attack(0.25)
                if self._switch_to_index(target.index):
                    ok = True
                    break
            if not ok:
                self._shot(f'xrs_switch_fail_{who}')   # ★留证：切人失败那一瞬间的界面（人工看是什么挡住了）
                self.logger.warning(f'xrs 直切 {who} 三次都没成功（不结束战斗，下一拍再试）')
                return False
        self.logger.info(f'xrs 直切到 {who} (slot{target.index + 1}) has_intro={has_intro}')
        self._handoff_to(target, has_intro)
        return True

    # ══════════════════ 状态机 ══════════════════
    def _skip(self, st):
        """这一拍不是我的 → 把场子交出去；连续 3 次没人接手就判定状态卡死，从循环轮重开。"""
        if st.get('next') == ME:
            st['next'] = None
        st['idle'] = st.get('idle', 0) + 1
        if st['idle'] >= 3:
            st.update({'step': 'suisui_loop', 'phase': 'loop', 'next': None, 'idle': 0})
            self.logger.warning('xrs 状态卡死（连续 3 次轮不到任何人）→ 从循环轮重开')
        return self._switch_out()

    def _hand_off(self, st, step, who):
        st['step'] = step
        st['next'] = who
        st['idle'] = 0

    def note_intro_handoff(self):
        self.intro_pending = True

    def take_intro(self):
        """本次入场是否带变奏；读完就清，避免下一轮误判。"""
        intro = bool(self.has_intro or self.intro_pending)
        self.intro_pending = False
        return intro

    # ─────────────── 必须覆盖的框架行为 ───────────────
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """本轴是固定顺序接力：状态里写着"该谁上"就谁上（MUST），其余人一律 NO。"""
        st = team_state(self.task)
        nxt = st.get('next')
        if nxt is None:
            return SwitchPriority.NORMAL
        return SwitchPriority.MUST if nxt == ME else SwitchPriority.NO

    def switch_other_char(self, allow_auto_combat=False):
        pass

    def healer_full_con_switch_locked(self):
        return False

    def on_combat_end(self, chars):
        try:
            setattr(self.task, STATE_ATTR, dict(INITIAL_STATE))
            self.logger.info('xrs 战斗结束 → 状态重置（下一场从心开局 → 穗穗 3A-E 开始）')
        except Exception:
            pass
