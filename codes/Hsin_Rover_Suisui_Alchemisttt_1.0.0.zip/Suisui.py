# -*- coding: utf-8 -*-
r"""穗穗（3号位 / 冷凝）—— 「心雷穗」轮椅轴（BV15gYF6GEPF）

本文件由 D:\Hermes-data\tools\okww-custom-char\build_xrs_team.py 生成；
改时间常数请直接改本文件（或改生成器后重新生成三份，保持公共块一致）。
"""
import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, Elements, SwitchPriority

STATE_ATTR = '_xrs_state'
ME = 'Suisui'

INITIAL_STATE = {'step': 'hsin_open', 'phase': 'open', 'next': 'Hsin', 'idle': 0}


def team_state(task):
    """队伍共享状态（挂在 task 上，三名角色各持一份同名代码也能看到同一个进度）。"""
    st = getattr(task, STATE_ATTR, None)
    if not isinstance(st, dict):
        st = dict(INITIAL_STATE)
        setattr(task, STATE_ATTR, st)
    return st


def con_of(char):
    try:
        return float(char.get_current_con() or 0)
    except Exception:
        return 0.0


class Suisui(BaseChar):
    """穗穗（3号位 / 冷凝）—— 「心雷穗」轮椅轴（参考视频 BV15gYF6GEPF）

    本轴里穗穗每轮上场**三次**：
      · suisui_open（启动第1拍）：3A（打满【水云息】回路）→ E（强化E·醒春潮升空）
        → 直接切雷主（面板这里没有「→变奏」，所以**不顶协奏**，省 0.8s）
      · suisui_burst（第3拍）：打满【芳菲信】(三格回路) → Q（声骸）→ R（大招）
        → 顶满协奏 → 变奏雷主（面板：→变奏主）
      · suisui_loop（循环第1拍）：E（变奏入场时水云息已满 → 先E落地）→ 补 3A
        → 直接切雷主（不顶协奏）
    循环轴第3拍是「A-Q-R」（启动轴是「4A-Q-R」）：_wait_forte3() 会一直打到三格回路满，
    所以两轮共用同一段代码（回路本来就满时它一帧都不多打）。
    """
    MY_STEPS = ('suisui_open', 'suisui_burst', 'suisui_loop')

    # ── 可调参数 ──
    OPEN_MIN_ATTACKS = 3       # 启动「3A-E」：先打够 3 下再考虑 E
    LOOP_ATTACKS = 3           # 循环「E-3A」：E 之后补 3A
    RISE_WAIT = 0.0            # 醒春潮后立刻切雷主（旧队实测：等升空会把下一棒起手吞掉）
    ULT_TRY_TIMEOUT = 10.0     # ★4→10s：0 能量不算满就"打满能量却不放大招"了 —— 改成狂按到放出来为止
    E_WAIT_BEFORE_SPAM = 3.0   # ★E 只"小等一下"；等不到就直接狂按（用户口径）
    E_SPAM_TIME = 2.5          # ★狂按 E 的总时长（期间普攻不停）
    E_PRESS_INTERVAL = 0.3     # ★"狂按"的定义（用户口径：0.2~0.4s 一次）

    VISIT_CAPS = {'suisui_open': 8.0, 'suisui_loop': 12.0, 'suisui_burst': 12.0}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._pin_ring_index()

    def _pin_ring_index(self):
        """把协奏环颜色钉成冷凝（ICE）。

        CharFactory 里 char_suisui 没配 ring_index → 实例化时是 -1，
        框架会按"颜色占比最大"现场猜；穗穗的濯雨时特效糊住能量环时会锁死错值，
        而本轴完全依赖读协奏决定"谁吃变奏"。（同 upstream custom_chars/Suisui.py。）"""
        try:
            if self.ring_index is None or self.ring_index < 0:
                self.ring_index = Elements.ICE
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self._pin_ring_index()

    # ══════════════════════════ 主流程 ══════════════════════════
    def do_perform(self):
        self._pin_ring_index()
        st = team_state(self.task)
        if st['step'] not in self.MY_STEPS:
            return self._skip(st)

        st['idle'] = 0
        self._visit_t0 = time.time()
        self.VISIT_CAP = self.VISIT_CAPS.get(st['step'], 12.0)
        intro = self.take_intro()
        step = st['step']
        t0 = time.time()
        skip_con = step in ('suisui_open', 'suisui_loop')   # 穗穗→雷主 两处都是直接切

        if step == 'suisui_open':
            self.logger.info(f'xrs 穗穗 启动第1拍：3A 打满水云息 → E(醒春潮升空) → 直接切雷主'
                             f'（变奏入场={intro}）')
            self._e_rise(min_attacks=self.OPEN_MIN_ATTACKS)
            self._hand_off(st, 'rover_open', 'Rover')
        elif step == 'suisui_loop':
            st['phase'] = 'loop'
            self.logger.info(f'xrs 穗穗 循环第1拍：E(醒春潮，变奏入场水云息已满) → 补3A → 直接切雷主'
                             f'（变奏入场={intro}）')
            self._e_rise(quick=bool(intro))    # 变奏入场那一拍：水云息已被消耗，E 放不出来 → 快速过
            self._attacks(self.LOOP_ATTACKS)
            self._hand_off(st, 'rover_open', 'Rover')
        else:
            self.logger.info('xrs 穗穗 第3拍：打满芳菲信 → Q(声骸) → R(大招) → 顶满协奏 → 变奏雷主')
            self._wait_forte3()
            self._echo()
            self._ult()
            self._fill_con()
            self._hand_off(st, 'rover_burst', 'Rover')

        self.logger.info(f'xrs 穗穗 本轮({step}) 用时 {time.time() - t0:.2f}s 协奏={con_of(self):.2f}')
        self._switch_out(skip_con=skip_con)

    # ══════════════════════════ 穗穗的判据 ══════════════════════════
    def _forte3_available(self):
        """芳菲信（三格回路）是否满：内置穗穗/工坊都用 threshold=0.75 才认，默认阈值会误判。"""
        try:
            return bool(self.task.find_one(Labels.suisui_forte3, threshold=0.75))
        except Exception:
            return False

    def _wait_forte3(self, timeout=8.0):
        """打普攻直到芳菲信(三格回路)满 —— 这是大招的回路，满了大招才有强化版+满协奏。
        图认不到就打到 timeout 兜底，不卡死。"""
        start = time.time()
        while time.time() - start < timeout:
            if self._forte3_available():
                self.logger.info(f'xrs 穗穗 芳菲信满(三格回路) 用时{time.time() - start:.1f}s')
                return True
            self.check_combat()
            self.click()
            time.sleep(0.15)
        self.logger.warning(f'xrs 穗穗 打满{timeout:.0f}s 芳菲信还没满 → 照放大招')
        return False

    def _e_ready(self):
        """E 亮了没有（水云息/E回路满，或 E 图标高亮）。两个信号取先亮的那个。"""
        try:
            return bool(self.is_e_forte_full()) or bool(self.task.find_one(Labels.suisui_e1))
        except Exception:
            return False

    def _e_rise(self, min_attacks=0, quick=False):
        """醒春潮（强化E·升空）：需要【水云息】(E回路)满。

        ★用户口径（也是实测教训）：**不要干等** —— 只"小等一下"（E_WAIT_BEFORE_SPAM=3s）
        看 E 亮不亮，等不到就**直接狂按 E**（一边按一边点普攻，水云息靠攻击攒）。
        17:05 那把循环第1拍就是干等 6s 没等到，后面 3A 还被本段预算掐掉。
        判据用 is_e_forte_full()/suisui_e1（**不是** suisui_forte3，那是芳菲信/大招的回路）。"""
        if quick:
            # ★变奏入场那一拍（循环第1拍）：变奏技能已经把【水云息】消耗掉、人已在濯雨时，
            #   E（醒春潮）根本放不出来（17:16 实测：小等3.1s + 狂按2.5s 全程没放出来）。
            #   → 只快速试两下，然后立刻去补 3A 交棒，不浪费 5.5s。
            self._press_e('E(醒春潮·变奏入场后大概率放不出)', hold=self.E_TAP)
            self.click()
            time.sleep(self.E_PRESS_INTERVAL)
            self._press_e('E(醒春潮) 第2次', hold=self.E_TAP)
            self.logger.info('xrs 穗穗 醒春潮 quick 模式（变奏入场后水云息已消耗）→ 直接去补 3A')
            time.sleep(self.RISE_WAIT)
            return False
        t0 = time.time()
        if min_attacks:
            self._attacks(min_attacks)
        ready = False
        while time.time() - t0 < self.E_WAIT_BEFORE_SPAM:
            if self._e_ready():
                ready = True
                break
            self.check_combat()
            self.click()
            time.sleep(0.15)
        self.logger.info(f'xrs 穗穗 E{"亮(水云息满)" if ready else "没等到(小等结束，直接狂按)"} '
                         f'用时{time.time() - t0:.1f}s')
        t0 = time.time()
        fired = False
        while time.time() - t0 < self.E_SPAM_TIME:
            self.send_resonance_key()
            self.click()                      # 狂按期间普攻不停
            time.sleep(self.E_PRESS_INTERVAL)
            if ready and not self._e_ready():
                fired = True
                break
        self.logger.info(f'xrs 穗穗 醒春潮{"已确认放出" if fired else "未确认(已狂按E)"} 用时{time.time() - t0:.1f}s')
        time.sleep(self.RISE_WAIT)

    def _ult(self):
        """R = 共鸣解放（穗穗大招）：边A边按 R —— 能量没满游戏会忽略这次按键，
        满了那一瞬间自己放出去（不会"没打满就放大"）。"""
        return self._ult_until_fired('大招')

    # ═══════════════════════════════════════════════════════════════════════
    #  以下为「心雷穗」三名角色共用的骨架（由 build_xrs_team.py 统一生成）
    #  设计对照：固定顺序接力 / 自己按数字键切人 / 状态机写在 task._xrs_state 上
    # ═══════════════════════════════════════════════════════════════════════

    # ─────────────────────── 可调参数（公共） ───────────────────────
    BETWEEN_ATTACK = 0.22       # 普攻间隔
    DODGE_SETTLE = 0.25         # 闪避之后的落地缓冲
    ECHO_SETTLE = 0.2           # 按 Q（声骸）之后等动作
    FILL_CON_TIMEOUT = 3.5      # 交棒前顶满协奏的时间上限（Rover 在自己类里覆盖成 2.0）
    E_SETTLE = 0.35             # 一次 E 之后等动作
    TEAM_WAIT_TIMEOUT = 4.0     # 交棒前等"队伍UI回来"的上限（大招演出期间它是 False）
    RETRY_TEAM_WAIT = 2.5       # ★重试时只等 2.5s：'队伍UI没回来'基本都是游戏在演出/加载，久等没意义
    SWITCH_TIMEOUT = 2.0        # 单程切人最长尝试时间
    SWITCH_KEY_INTERVAL = 0.12  # 连按数字键的间隔
    SWITCH_SETTLE = 0.55        # 切过去之后等站稳（0.50/0.52 会把下一棒起手吞掉）
    SETTLE_ATTACK_INTERVAL = 0.42
    HANDOFF_CON_WAIT = 0.8      # 交棒前轮询协奏是否满的上限（必须在按切人键之前读）
    HANDOFF_CON_POLL = 0.1
    POKE_INTERVAL = 0.12        # 连点地板：再密会被吞/变成下落攻击
    POKE_READ_EVERY = 3         # 每 3 下普攻才读一次屏（≈0.36s，节流）
    SKIP_CHECK_AFTER_ULT = 5.0  # 大招/变身/交棒之后多久内不做"战斗结束"判定
    CON_FULL_EPS = 0.90         # ok-ww 把满环钳成 0.99、读数有 ±5% 抖动 → ≥0.90 就算满
    ULT_CD_MIN = 15.0           # R 的 CD 读数 ≥15s ⇒ "R 真放出去了"（三人大招 CD 都是 20s 级）
    VISIT_CAP = 12.0            # 兜底预算（没在 VISIT_CAPS 里配的段）
    intro_pending = False       # 持久标记：reset_state() 会把 has_intro 清成 False
    intro_motion_freeze_duration = 0.9

    # ══════════════ 本段站场的硬时间预算（抗干扰 + 不挨打） ══════════════
    def _over_budget(self):
        """本段站场时间是否已超过预算（超了就放弃剩余动作直接交棒）。"""
        cap = getattr(self, 'VISIT_CAP', 12.0)
        t0 = getattr(self, '_visit_t0', None)
        if t0 is None or time.time() - t0 < cap:
            return False
        self.logger.warning(f'xrs {ME} 本段站场已达上限 {cap:.0f}s → 放弃剩余动作直接交棒（抗干扰）')
        self._visit_t0 = time.time()      # 重置，避免同一段反复刷同一行日志
        return True

    # ══════════════════════════ 动作原语 ══════════════════════════
    def _attacks(self, count):
        for _ in range(int(count)):
            if self._over_budget():
                return
            self.check_combat()
            self.click()
            time.sleep(self.BETWEEN_ATTACK)

    def _dodge(self):
        try:
            self.task.send_key(self.task.key_config.get('Dodge Key', 'lshift'))
            time.sleep(self.DODGE_SETTLE)
        except Exception as e:
            self.logger.debug(f'xrs 闪避异常 {e}')

    def _press_e(self, tag, hold=0.05):
        """按一下 E（共鸣技能），**不看 resonance_available()**。

        为什么去掉门槛：resonance_available() = has_cd() = OCR 读技能图标上的冷却数字，
        第一下 E 之后它必然是 False → 会把整段强E 判成"不可用"跳过（旧队实战日志原文：
        `xbs 心 强E 不可用(E在冷却)→跳过`）。识别类判据只配写日志，不配决定流程。
        hold>0.06s 时 send_key 会走 keyDown→sleep→keyUp，一次调用同时覆盖短按/长按两种机制。
        """
        key = 'e'
        try:
            key = self.get_resonance_key()
        except Exception:
            pass
        try:
            self.task.send_key(key, down_time=max(hold, 0.02))
            time.sleep(0.05)
        except Exception as e:
            self.logger.debug(f'xrs {ME} {tag} 按键异常 {e}')
        self.logger.info(f'xrs {ME} {tag} ← 按下 E(hold={hold:.2f}s) CD读数={self._cd_readout()}')

    def _cd_readout(self, box='resonance'):
        """读一次技能冷却读数（只写日志 / 当"刚按的技能真放出来了"的复核）。"""
        try:
            return round(float(self.task.get_cd(box)), 2)
        except Exception:
            return None

    def _echo(self):
        """Q = 声骸技能。"""
        try:
            if self.echo_available():
                self.click_echo(time_out=0)
                time.sleep(self.ECHO_SETTLE)
            else:
                self.logger.info(f'xrs {ME} 声骸不可用，跳过 Q')
        except Exception as e:
            self.logger.debug(f'xrs {ME} 声骸异常 {e}')

    def _shot(self, name):
        """留一张实战截图（随 OK-WW-log.zip 的 screenshots/ 回来）。

        【电涌】【照世心】【霆心域】这类资源条没有模板图，只能留证人工看 —— 别拿
        不可靠的识别结果去卡流程。"""
        try:
            self.task.screenshot(name)
        except Exception as e:
            self.logger.debug(f'xrs 截图 {name} 失败 {e}')

    # ═══════ 学 爱达千 那条轴：\u300c边A边等条件成立\u300d（不是站着干等） ═══════
    # ═══════════ 判定层（学爱达千 Aemeath.py）═══════════
    # 为什么不再用 get_cd() 的 CD 读数当"技能真放出去了吗"的凭据：
    #   OCR 有 ~1s 渲染延迟（按完立刻读是旧值），演出/特效糊住时整段读不到 → 判定又晚又错。
    # 改成：① 自己记"什么时候按过/放出去了"（_record / _since）；
    #       ② 时间口径用框架的 time_elapsed_accounting_for_freeze（**自动扣掉演出冻结时间**）；
    #       ③ "大招出手"用**队伍UI消失**判定（爱达千注释原文：演出期间的按键会被带过边界，
    #          演出一结束就兑现）—— 所以要狂按，而不是"按一次然后等读数"。
    LIB_CD = 25.0                 # 大招 CD（本队三人都是 20~25s 级）
    R_MASH_INTERVAL = 0.06        # 狂按 R 的间隔（爱达千 R2_KEY_INTERVAL=0.05 / EF_SPAM_INTERVAL=0.08）
    R_MASH_WINDOW = 3.5           # 狂按 R 的窗口长度（到点没出手就照常往下走）
    SPIN_CLICK_INTERVAL = 0.12    # "连点窗口"里的点击间隔（爱达千同名常量同值）
    A_CHAIN_INTERVAL = 0.33       # ★连续普攻的点击间隔：**按游戏普攻动画的自然节奏**。
                                  #   原来 0.16s 太密（日志里"连打 46 下"其实大半被吞，
                                  #   连段起不来 → 照世心/能量都攒不满）。参考包爱达千的连点窗口
                                  #   也是 4~5 下用 1.45s ≈ 0.33s/下。
    E_TAP = 0.05                  # 短按 E 的默认按压时长（共鸣技能）
    E_READY_CD = 0.6              # E 的 CD 读数 ≤0.6s（且 >0.05）⇒ "有 E 可放"
    E_MIN_ATTACKS = 3             # ★拍8 最少连打几下（松松的兜底，防止 0 下就收工）
    E_MIN_TIME = 1.5              # ★拍8 最少时长（用户口径：有 E 就赶紧放，别被"最少时长"拖住）
    E_PRESS_GAP = 0.35            # ★两次按 E 之间至少隔这么久（防同一个窗口重复按；别设太大，用户要"有E就放"）
    E_SPAM_MAX = 8                # 拍8 里"有E就放E"最多放几次（防呆）

    def _marks(self):
        m = getattr(self, '_xrs_marks', None)
        if m is None:
            m = {}
            self._xrs_marks = m
        return m

    def _record(self, key):
        """记一笔"这个动作我做过/这个技能放出去了"（自记账，供后面推算可用性）。"""
        self._marks()[key] = time.time()
        return self._marks()[key]

    def _elapsed(self, t):
        """从 t 到现在，**扣除演出冻结时间**（框架 API；拿不到就退回原始差值）。"""
        try:
            return self.time_elapsed_accounting_for_freeze(t)
        except Exception:
            return time.time() - t

    def _since(self, key):
        t = self._marks().get(key)
        return None if t is None else self._elapsed(t)

    def _lib_by_record_ready(self):
        """按自记账推算"现在能不能放大招"（没放过 / CD 已过 → 能）。只写日志用。"""
        s = self._since('liber')
        return s is None or s >= self.LIB_CD

    def _spam_r_until_fired(self, tag, window=None, poke=False, poll=None):
        """★狂按 R 直到"真出手"（学爱达千 `spam_r_e_until_lib`）。

        判定 = **队伍UI消失**（= 大招演出开始 = 出手了）。演出期间的按键会被"带过边界"，
        演出一结束就兑现 —— 所以狂按才对，而不是"按一次再等 CD 读数"（读数慢 ~1s）。
        出手或到窗口上限都停，两种情况都写日志（绝不卡死）。"""
        window = self.R_MASH_WINDOW if window is None else window
        poll = self.R_MASH_INTERVAL if poll is None else poll
        start = time.time()
        n = 0
        fired = False
        while self._elapsed(start) < window:
            if self._over_budget():
                break
            # 战斗判定用**容忍版**：演出/大招期间 target 会瞬断，单次失败不该结束整场
            #   （真·不在战斗时连续 20 次 ≈1.5s 后照样收场，不会像 19:12 那把空跑 55s）
            self._check_combat_tolerant('狂按R')
            n += 1
            try:
                self.send_liberation_key()
            except Exception as e:
                self.logger.debug(f'xrs {ME} 狂按 R 异常 {e}')
            try:
                self.task.next_frame()          # 每发一次键取一帧（参考包同款做法）
            except Exception:
                pass
            try:
                if not self.task.in_team()[0]:  # 队伍UI消失 = 演出开始 = 出手
                    fired = True
                    break
            except Exception:
                pass
            if poke:
                self.click()
            time.sleep(poll)
        if fired:
            self._record('liber')
        self.logger.info(f'xrs {ME} {tag} 狂按 R ×{n}（{self._elapsed(start):.2f}s）→ '
                         f'{"已出手（队伍UI消失）" if fired else "窗口到上限还没出手"}')
        return fired

    COMBAT_MISS_LIMIT = 20    # ★连续这么多次战斗判定失败才真的收场（演出/大招期间 target 会瞬断）

    def _check_combat_tolerant(self, tag=''):
        """战斗判定的**容忍版**：单次失败不结束战斗，连续 COMBAT_MISS_LIMIT 次才抛。

        为什么必须有：`task.check_combat()` 一旦判失败就 `raise_not_in_combat` → **整场战斗结束**。
        我们新加的狂按循环每 0.06s 查一次（比框架自己的频率高得多），演出/大招/变身期间
        target 瞬间丢失就会被命中 → 用户看到的"刚变奏到心，没过一会战斗就结束了"就是这么来的。
        容忍版：短暂瞬断继续按，真·不在战斗（连续 20 次 ≈ 1.5s）才让框架收场。"""
        try:
            self.check_combat()
            self._combat_miss = 0
        except Exception as e:
            self._combat_miss = getattr(self, '_combat_miss', 0) + 1
            if self._combat_miss >= self.COMBAT_MISS_LIMIT:
                self.logger.warning(f'xrs {ME} 战斗判定连续失败 {self._combat_miss} 次 → 收场（{e}）')
                raise
            self.logger.debug(f'xrs {ME} 战斗判定失败第{self._combat_miss}次（容忍中）{e}')

    def _frame_once(self):
        """取**最新**帧。

        ★关键（19:16 实测）：框架的画面只在有人调用 `task.next_frame()` 时才更新 ——
        我们的长按/等待循环里没人调，`find_one` 就一直在读**同一张旧帧**：
        表现是"高亮永远不变"（长按撞到 5.5s 上限才松、"等3.2s 高亮没亮"其实是读旧帧）。
        参考包（爱达千）的每个轮询都带一句 `self.task.next_frame()`，必须补上。"""
        try:
            f = self.task.next_frame()
            if f is not None:
                return f
        except Exception:
            pass
        try:
            return self.task.frame
        except Exception:
            return None

    def _press_e_verified(self, tag='', tries=3, hold=None, gap=0.4):
        """★按 E **并复核真的放出去了**（CD 读数跳起来才算），没生效就重按。

        用户口径 + 日志证据（19:58 那把）：我们连按 3 次 E，**只有 1 次真生效**
        （CD 读数 19.99 ✓），另两次读到的是 -0.0 / 19.19（无效）。
        屏幕上就是"3A 打完了却不点 E / 不点强E" —— 因为按了的那几次被动作吞掉了。"""
        hold = self.E_TAP if hold is None else hold
        for i in range(tries):
            if self._over_budget():
                return False
            before = self._cd_readout()
            self._press_e(f'{tag} 第{i + 1}次', hold=hold)
            time.sleep(0.35)                     # 等 CD 数字渲染出来（~0.3s）
            after = self._cd_readout()
            if after is not None and after > 0.05 and (before is None or after > before + 0.5):
                self.logger.info(f'xrs 心 {tag} 已生效（CD {before} → {after}）')
                return True
            self.logger.info(f'xrs 心 {tag} 第{i + 1}次没生效（CD {before} → {after}）→ 重按')
            time.sleep(gap)
        self.logger.warning(f'xrs 心 {tag} 连按 {tries} 次都没确认生效')
        return False

    def _e_ready_now(self, tag=''):
        """"有 E 就放 E" 的判据：E 的 CD 读数已好，**或** E 图标正在发光（高亮=可用）。

        用户口径（19:4x）："3ae强e 那段，也要检测有 e 就放 e，不然浪费时间"。
        用两个信号取或：① CD 读数 ≤ E_READY_CD；② 框架的颜色判定 box_highlighted('resonance')
        （E 图标上的白色高亮 —— 这是"技能可用"最直接的画面信号，不受 OCR 延迟影响）。"""
        # ★CD 读数 -0.0 / 0.0 绝不能当"E 好了"：那只是"图标上没有数字"，
        #   可能是读数没画出来/读失败（19:50 那把就是被它骗了：1.6 秒内"有E就放"两次 → 误判拍8 收工）
        cd = self._cd_readout()
        if cd is not None and 0.05 < cd <= self.E_READY_CD:
            return True, f'CD读数={cd}'
        try:
            if self.task.box_highlighted('resonance'):     # E 图标白色高亮 = 最可靠的"可用"
                return True, '图标高亮'
        except Exception:
            pass
        return False, ''

    def _attack_chain(self, n, tag=''):
        """★连续 n 下普攻：**一口气打完**（中间不插闪避、不插任何检查）。

        用户口径（19:31）："3A 被拆分了，非常不连贯，浪费时间" ——
        上一版每下点击之间还夹了战斗判定/取帧，连段被打散。这里只发点击。"""
        if not n:
            return
        self._check_combat_tolerant(tag or '连打')
        for _ in range(int(n)):
            self.click()
            time.sleep(self.A_CHAIN_INTERVAL)
        self.logger.debug(f'xrs 心 {tag} 连打 {int(n)} 下')

    def _combo_3a_dodge_2a(self, tag=''):
        """★教学原文：「a，a，a **与闪同时按**，之后再接两次 a」。

        3 下普攻，**第 3 下按完立刻闪避**（闪避取消 3A 的后摇 —— 这是省时间的关键），
        再补 2 下普攻。**不用固定窗口等**：等窗口＝把后摇完整吃下来，
        强化形态的倒计时里白白烧掉一秒多（用户："a3 后摇太浪费时间导致掉 buff"）。"""
        self._check_combat_tolerant('3A+闪')
        t0 = time.time()
        for i in range(3):
            self.click()
            if i == 2:
                self._dodge()                       # ★与第 3 下**同一帧**发出（中间不再 sleep）
            else:
                time.sleep(self.A_CHAIN_INTERVAL)   # ★按普攻动画的自然节奏（0.33s）
        time.sleep(self.DODGE_SETTLE)               # 闪避落地缓冲，再补 2A（否则 2A 落在闪避动作里）
        for _ in range(2):
            self.click()
            time.sleep(self.A_CHAIN_INTERVAL)
        self.logger.info(f'xrs 心 3A+闪+2A 走完（{self._elapsed(t0):.1f}s，'
                         f'3A+闪同帧 → 缓冲{self.DODGE_SETTLE}s → 2A）')

    def _attack_window(self, seconds, tag=''):
        """★"连点窗口"（学爱达千）：窗口内每 SPIN_CLICK_INTERVAL 点一次普攻。

        为什么不是"点 n 下、固定 0.22s 一下"：演出/后摇会把贴着的点击**丢掉**（不排队），
        stride 猜错一次这几段连段就断了；窗口内连续点才接得上（心的 3A/2A 都用它）。"""
        start = time.time()
        n = 0
        self._check_combat_tolerant('连点窗口')
        while self._elapsed(start) < seconds:
            if self._over_budget():
                break
            self.click()
            n += 1
            time.sleep(self.SPIN_CLICK_INTERVAL)
        self.logger.debug(f'xrs {ME} {tag} 连点窗口 {seconds:.2f}s 共 {n} 下')
        return n

    def _poke_until(self, ready, timeout, interval=None, on_poke=None):
        """边点普攻边等 ready() 成立；成立立刻返回 True。到 timeout 返回 False（绝不卡死）。"""
        interval = interval or self.POKE_INTERVAL
        start = time.time()
        while True:
            if ready():
                return True
            if time.time() - start >= timeout:
                return False
            try:
                self.check_combat()
            except Exception:
                return False
            if on_poke is not None:
                try:
                    on_poke()
                except Exception:
                    pass
            self.click()
            time.sleep(interval)

    # ═══════ 大招/变身/交棒期间别让框架判"战斗结束" ═══════
    # 现象：屏幕上什么都看不见的那几秒（变身、变奏入场、R2），CombatCheck 会
    #   target lost ×3 → "target_enemy failed → break out of combat" → 整场战斗结束
    #   → on_combat_end 把状态机清空 → 下一场从开局重来。
    # 框架留了口子：CombatCheck.do_check_in_combat 先问当前角色的 skip_combat_check()。
    def _mark_busy(self, seconds=None):
        try:
            self.task._xrs_skip_check_until = time.time() + (seconds or self.SKIP_CHECK_AFTER_ULT)
        except Exception:
            pass

    def skip_combat_check(self):
        try:
            return time.time() < getattr(self.task, '_xrs_skip_check_until', 0)
        except Exception:
            return False

    # ═══════════ 固定顺序「直接切人」 ═══════════
    # 不用框架的 switch_next_char()：① 它按 get_switch_priority() 现场挑人，顺序会漂；
    #   ② 它一旦认不到队伍UI 就 raise_not_in_combat("not in_team while switching")
    #      → 直接结束整场战斗（旧队实战日志 19:23:18 / 19:24:22 两次就是这么被打断的）；
    #   ③ 它有几处"顺手补普攻"，会把要立刻走人的节奏拖乱。
    # 代价：框架的交接记账要自己补（全在 _handoff_to 里）。
    def _char_by_name(self, name):
        for c in getattr(self.task, 'chars', []) or []:
            if c is not None and getattr(c, 'name', None) == name:
                return c
        return None

    def _switch_to_index(self, index):
        """按数字键切到指定队伍位置，直到 in_team 确认切过去（超时就放弃，不抛异常）。"""
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                break
            if in_team and current_index == index:
                self._settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            time.sleep(self.SWITCH_KEY_INTERVAL)
        return False

    def _settle_with_attack(self, duration, attack=False):
        """等 duration 秒，期间保持点普攻（不干等，两边连段都不掉）。"""
        end = time.time() + min(float(duration), 3.0)
        while time.time() < end:
            if attack:
                self.click()
            time.sleep(min(0.1, max(0.0, end - time.time())))

    def _con_full(self):
        """协奏是否满：读到的值 ≥ CON_FULL_EPS 就算满（框架会把满环钳成 0.99）。"""
        try:
            val = self.get_current_con()
        except Exception:
            val = 0
        try:
            if self.is_con_full():
                return True
        except Exception:
            pass
        try:
            return float(val or 0) >= self.CON_FULL_EPS
        except Exception:
            return False


    def _ult_fired(self, timeout=1.0, poke=True):
        """按了 R 之后判断有没有真放出来。只认三件事：**R 自己的 CD 起来了** / 队伍UI消失 / 协奏值跳涨
        （协奏本来就满时不做跳涨判断，否则会误判成"放出来了"）。
        为什么加 CD 这一条：队伍UI消失会被弹窗/演出误报，而 CD 读数最直白 ——
        R 真放出去了，图标上就会开始走它的 CD（心 25s 级、雷主 25s、穗穗 ~20s）。"""
        try:
            before = con_of(self)
        except Exception:
            before = 0.0
        use_con = before < 0.95
        start = time.time()
        while time.time() - start < timeout:
            cd = self._cd_readout('liberation')
            if cd is not None and cd >= self.ULT_CD_MIN:
                return True
            try:
                if not self.task.in_team()[0]:
                    return True
            except Exception:
                pass
            if use_con:
                try:
                    if con_of(self) >= min(1.0, before + 0.12):
                        return True
                except Exception:
                    pass
            if poke:
                try:
                    self.click()  # 等待期间继续点普攻，别让角色站着
                except Exception:
                    pass
            # ★poke=False 时这一轮**一下都不点**：用户实测看到"强E 后还打了一下普攻才 R"，
            #   根源就是这里 —— 原来无论 poke 与否都在这里 click（雷主 R 之间被插了普攻）。
            time.sleep(0.1)
        return False

    def _ult_until_fired(self, tag, timeout=None, poke=True, poll=0.3):
        """按 R 直到放出来（能量够不够让游戏自己判断），放出来立刻停手。

        poke=True   ：边A边按 R（等待期间继续攒能量，适合"能量还没满要攒"的角色）
        poke=False  ：只按 R、不夹普攻（适合"上一步刚确认过能放"的场合 —— 视频里
                      雷主就是 强E → 立即接 R，中间不插普攻）。
        poll        ：两次按 R 之间等多久。**用户口径的"狂" = 0.2~0.4s 一次**，默认 0.3。"""
        timeout = self.ULT_TRY_TIMEOUT if timeout is None else timeout
        start = time.time()
        tries = 0
        while time.time() - start < timeout:
            self._mark_busy(6.0)
            tries += 1
            self.send_liberation_key()
            if self._ult_fired(poll, poke=poke):
                self.logger.info(f'xrs {ME} {tag} 已放出（按 R：第 {tries} 次，'
                                 f'{time.time() - start:.1f}s）')
                return True
            try:
                self.check_combat()
            except Exception:
                break
            if poke:
                self.click()
            time.sleep(0.2)
        self.logger.warning(f'xrs {ME} {tag} 边A边按 R {timeout:.0f}s 仍没放出来（共鸣能量不够）')
        return False

    def _fill_con(self):
        """离场前把协奏顶满（本轴里 →变奏X 的每一棒都要顶满才走）。只普攻。"""
        start = time.time()
        full = False
        # 顶协奏之前必须先等"队伍UI回来"：大招演出/变身期间 UI 隐藏，那时读协奏只能读到 0.00
        self._wait_team_visible(5.0)
        # ★注意：生成器是「body + SHARED」拼接 → SHARED 里的定义会**覆盖** body 里的同名常量，
        #   所以角色想改自己的顶协奏上限要用 xxx_OVERRIDE（本轴：雷主 2.0s、其余用 SHARED 的 3.5s）
        timeout = getattr(self, 'FILL_CON_TIMEOUT_OVERRIDE', self.FILL_CON_TIMEOUT)
        zero_since = None
        while True:
            if self._con_full():
                full = True
                break
            # ★协奏读数一直 0.00 = 元素环读不到（特效糊住/特效期间），
            #   这种情况顶到底也没用（日志里出现 10 次，每次白等 2~3.5s）→ 1.5s 就放弃并如实记日志
            if con_of(self) <= 0.02:
                zero_since = zero_since or time.time()
                if time.time() - zero_since >= 1.5:
                    self.logger.warning('xrs 协奏读数一直是 0.00（环读不到）→ 不再干等，直接交棒'
                                        '（给不给变奏由游戏按真值决定）')
                    break
            else:
                zero_since = None
            if time.time() - start >= timeout or self._over_budget():
                break
            self.check_combat()
            self.click()
            time.sleep(0.15)
        self.logger.info(f'xrs {ME} 交棒前协奏={con_of(self):.2f} full={full} 用时{time.time() - start:.1f}s')
        if not full:
            self.logger.warning(
                f'xrs {ME} 协奏到上限还没满（{con_of(self):.2f}）→ 下一棒吃不到变奏；'
                f'反复出现就检查共鸣效率（视频要求：心117 / 雷主134 / 穗穗260+）')
        return full

    def _wait_con_full(self):
        """交棒前轮询协奏（必须在按切人键之前读：切走后能量环显示的是新角色的）。"""
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self._con_full():
                return True
            time.sleep(self.HANDOFF_CON_POLL)
        self.logger.info(f'xrs {ME} 交棒前协奏={con_of(self):.2f} 没满（读数只记录，给不给变奏由游戏按真值决定）')
        return False

    def _handoff_to(self, target, has_intro):
        """补上框架交接记账（自己按数字键切人会绕开它，不补 get_current_char() 会返回 None）。"""
        self.task.in_liberation = False
        try:
            self.switch_out(con_full=has_intro)
        except Exception:
            pass
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            try:
                self.task.add_freeze_duration(now, getattr(target, 'intro_motion_freeze_duration', 0.9), -100)
            except Exception:
                pass
            self.last_outro_time = now

    def _wait_team_visible(self, timeout=None):
        """等"队伍UI回来"（大招演出/变身期间 in_team()[0] 是 False）。

        日志实证：切人那一刻队伍UI认不到 → 框架直接结束整场战斗。所以切人前先把它等回来。"""
        timeout = self.TEAM_WAIT_TIMEOUT if timeout is None else timeout
        start = time.time()
        while time.time() - start < timeout:
            try:
                if self.task.in_team()[0]:
                    return True
            except Exception:
                return False
            try:
                self.click()      # 等待期间保持输入，别发呆
            except Exception:
                pass
            time.sleep(0.25)
        self.logger.warning(f'xrs 交棒前等了 {timeout}s 队伍UI都没回来，照常切人')
        return False

    def _switch_out(self, skip_con=False):
        """按状态里的 next 固定顺序直切（不用框架 switch_next_char）。"""
        st = team_state(self.task)
        who = st.get('next')
        target = self._char_by_name(who)
        if target is None:
            self.logger.warning(f'xrs 状态里的接棒人 {who} 找不到 → 交回框架选人')
            return self.switch_next_char()
        self._mark_busy(4.0)
        self._wait_team_visible()                      # 大招演出期间按键会被吞，先等 UI 回来
        has_intro = False if skip_con else self._wait_con_full()
        ok = self._switch_to_index(target.index)
        if not ok:
            for attempt in range(2):
                self.logger.warning(f'xrs 直切 {who} 失败 → 就地重试第 {attempt + 1} 次')
                self._wait_team_visible(self.RETRY_TEAM_WAIT)
                self._settle_with_attack(0.25)
                if self._switch_to_index(target.index):
                    ok = True
                    break
            if not ok:
                self._shot(f'xrs_switch_fail_{who}')   # ★留证：切人失败那一瞬间的界面（人工看是什么挡住了）
                self.logger.warning(f'xrs 直切 {who} 三次都没成功（不结束战斗，下一拍再试）')
                return False
        self.logger.info(f'xrs 直切到 {who} (slot{target.index + 1}) has_intro={has_intro}')
        self._handoff_to(target, has_intro)
        return True

    # ══════════════════ 状态机 ══════════════════
    def _skip(self, st):
        """这一拍不是我的 → 把场子交出去；连续 3 次没人接手就判定状态卡死，从循环轮重开。"""
        if st.get('next') == ME:
            st['next'] = None
        st['idle'] = st.get('idle', 0) + 1
        if st['idle'] >= 3:
            st.update({'step': 'suisui_loop', 'phase': 'loop', 'next': None, 'idle': 0})
            self.logger.warning('xrs 状态卡死（连续 3 次轮不到任何人）→ 从循环轮重开')
        return self._switch_out()

    def _hand_off(self, st, step, who):
        st['step'] = step
        st['next'] = who
        st['idle'] = 0

    def note_intro_handoff(self):
        self.intro_pending = True

    def take_intro(self):
        """本次入场是否带变奏；读完就清，避免下一轮误判。"""
        intro = bool(self.has_intro or self.intro_pending)
        self.intro_pending = False
        return intro

    # ─────────────── 必须覆盖的框架行为 ───────────────
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """本轴是固定顺序接力：状态里写着"该谁上"就谁上（MUST），其余人一律 NO。"""
        st = team_state(self.task)
        nxt = st.get('next')
        if nxt is None:
            return SwitchPriority.NORMAL
        return SwitchPriority.MUST if nxt == ME else SwitchPriority.NO

    def switch_other_char(self, allow_auto_combat=False):
        pass

    def healer_full_con_switch_locked(self):
        return False

    def on_combat_end(self, chars):
        try:
            setattr(self.task, STATE_ATTR, dict(INITIAL_STATE))
            self.logger.info('xrs 战斗结束 → 状态重置（下一场从心开局 → 穗穗 3A-E 开始）')
        except Exception:
            pass
